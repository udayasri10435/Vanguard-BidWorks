import React, { useState, useEffect } from 'react';
import {
  Project,
  PlanSheet,
  TakeoffItem,
  CostDatabaseItem,
  EstimateLineItem,
  TradePackage,
  SubcontractorBid,
  HistoricalBid,
} from './types';
import { AppStorage, MarkupSettings } from './utils/storage';
import { calculateEstimateFinancials, formatCurrency, formatNumber } from './utils/calculations';
import { regionalModifiers } from './data/initialData';

import { Navigation, ActiveTab } from './components/Navigation';
import { TakeoffCanvas } from './components/Takeoffs/TakeoffCanvas';
import { EstimateSpreadsheet } from './components/Estimate/EstimateSpreadsheet';
import { FinancialMarkupSidebar } from './components/Estimate/FinancialMarkupSidebar';
import { CostCatalog } from './components/CostDatabase/CostCatalog';
import { BidLevelingMatrix } from './components/Subcontractors/BidLevelingMatrix';
import { WinLossDashboard } from './components/Analytics/WinLossDashboard';
import { ProposalGenerator } from './components/Proposal/ProposalGenerator';
import { AiEstimatorModal } from './components/AIAssistant/AiEstimatorModal';

import { MapPin, Calendar, Building2, Square, Plus, Database, Sparkles, RefreshCw } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('estimate');

  // Application Data States initialized from AppStorage
  const [projects, setProjects] = useState<Project[]>(() => AppStorage.getProjects());
  const [activeProjectId, setActiveProjectId] = useState<string>(() => AppStorage.getActiveProjectId());
  const [planSheets, setPlanSheets] = useState<PlanSheet[]>(() => AppStorage.getPlanSheets());
  const [activeSheetId, setActiveSheetId] = useState<string>(() => planSheets[0]?.id || 'sheet-01');
  const [takeoffs, setTakeoffs] = useState<TakeoffItem[]>(() => AppStorage.getTakeoffs());
  const [costDatabase, setCostDatabase] = useState<CostDatabaseItem[]>(() => AppStorage.getCostDatabase());
  const [estimateItems, setEstimateItems] = useState<EstimateLineItem[]>(() => AppStorage.getEstimateItems());
  const [tradePackages, setTradePackages] = useState<TradePackage[]>(() => AppStorage.getTradePackages());
  const [subBids, setSubBids] = useState<SubcontractorBid[]>(() => AppStorage.getSubBids());
  const [historicalBids, setHistoricalBids] = useState<HistoricalBid[]>(() => AppStorage.getHistoricalBids());
  const [markupSettings, setMarkupSettings] = useState<MarkupSettings>(() => AppStorage.getMarkupSettings());

  // Modals
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);
  const [isCostDbPickerOpen, setIsCostDbPickerOpen] = useState<boolean>(false);

  // Active Project & Active Sheet
  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0];
  const activeSheet = planSheets.find((s) => s.id === activeSheetId) || planSheets[0];

  // Regional Multiplier for active project
  const activeRegion =
    regionalModifiers.find((r) => r.key === activeProject.regionFactorKey) ||
    regionalModifiers[0];

  // Project-specific Estimate Items
  const projectEstimateItems = estimateItems.filter((i) => i.projectId === activeProject.id);

  // Synchronize with LocalStorage
  useEffect(() => {
    AppStorage.setProjects(projects);
  }, [projects]);

  useEffect(() => {
    AppStorage.setActiveProjectId(activeProjectId);
  }, [activeProjectId]);

  useEffect(() => {
    AppStorage.setPlanSheets(planSheets);
  }, [planSheets]);

  useEffect(() => {
    AppStorage.setTakeoffs(takeoffs);
  }, [takeoffs]);

  useEffect(() => {
    AppStorage.setCostDatabase(costDatabase);
  }, [costDatabase]);

  useEffect(() => {
    AppStorage.setEstimateItems(estimateItems);
  }, [estimateItems]);

  useEffect(() => {
    AppStorage.setTradePackages(tradePackages);
  }, [tradePackages]);

  useEffect(() => {
    AppStorage.setSubBids(subBids);
  }, [subBids]);

  useEffect(() => {
    AppStorage.setHistoricalBids(historicalBids);
  }, [historicalBids]);

  useEffect(() => {
    AppStorage.setMarkupSettings(markupSettings);
  }, [markupSettings]);

  // Financial Calculations
  const financials = calculateEstimateFinancials(
    projectEstimateItems,
    markupSettings,
    activeProject.squareFootage,
    activeRegion.laborFactor,
    activeRegion.materialFactor
  );

  // Handlers for Takeoffs
  const handleAddTakeoff = (item: TakeoffItem) => {
    setTakeoffs((prev) => [...prev, item]);
  };

  const handleUpdateTakeoff = (updated: TakeoffItem) => {
    setTakeoffs((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));

    // If linked to an estimate item, update that estimate item's quantity!
    if (updated.linkedEstimateItemId) {
      setEstimateItems((prev) =>
        prev.map((item) =>
          item.id === updated.linkedEstimateItemId
            ? {
                ...item,
                quantity: updated.measurementValue,
                takeoffLabel: `${updated.name} (${formatNumber(updated.measurementValue)} ${updated.unit})`,
              }
            : item
        )
      );
    }
  };

  const handleDeleteTakeoff = (id: string) => {
    setTakeoffs((prev) => prev.filter((t) => t.id !== id));
    // Unlink any estimate line
    setEstimateItems((prev) =>
      prev.map((item) => (item.takeoffId === id ? { ...item, takeoffId: undefined, takeoffLabel: undefined } : item))
    );
  };

  const handleUpdateSheetScale = (sheetId: string, newRatio: number, label: string) => {
    setPlanSheets((prev) =>
      prev.map((s) => (s.id === sheetId ? { ...s, scaleRatio: newRatio, scaleLabel: label } : s))
    );
  };

  const handleLinkTakeoffToEstimate = (takeoff: TakeoffItem, estimateItemId: string) => {
    // 1. Update takeoff
    setTakeoffs((prev) =>
      prev.map((t) => (t.id === takeoff.id ? { ...t, linkedEstimateItemId: estimateItemId } : t))
    );
    // 2. Update estimate item quantity to match takeoff measurement!
    setEstimateItems((prev) =>
      prev.map((item) =>
        item.id === estimateItemId
          ? {
              ...item,
              takeoffId: takeoff.id,
              quantity: takeoff.measurementValue,
              takeoffLabel: `${takeoff.name} (${formatNumber(takeoff.measurementValue)} ${takeoff.unit})`,
            }
          : item
      )
    );
  };

  const handleCreateEstimateFromTakeoff = (takeoff: TakeoffItem, itemCode: string) => {
    // Find unit pricing from database or default
    const dbItem = costDatabase.find(
      (db) => db.itemCode.startsWith(takeoff.divisionCode) || db.divisionCode === takeoff.divisionCode
    );

    const newItem: EstimateLineItem = {
      id: 'est-' + Date.now(),
      projectId: activeProject.id,
      divisionCode: takeoff.divisionCode,
      divisionName: dbItem?.divisionName || 'Trade Scope',
      itemCode: dbItem?.itemCode || `${takeoff.divisionCode}-0100`,
      description: `${takeoff.name}`,
      takeoffId: takeoff.id,
      takeoffLabel: `${takeoff.name} (${formatNumber(takeoff.measurementValue)} ${takeoff.unit})`,
      quantity: takeoff.measurementValue,
      unit: takeoff.unit,
      laborRate: dbItem?.laborRate || 5.0,
      materialRate: dbItem?.materialRate || 4.5,
      equipmentRate: dbItem?.equipmentRate || 0.5,
      subcontractorRate: 0,
      notes: 'Generated from Plan Takeoff measurement',
    };

    setEstimateItems((prev) => [...prev, newItem]);
    // Link takeoff back
    setTakeoffs((prev) =>
      prev.map((t) => (t.id === takeoff.id ? { ...t, linkedEstimateItemId: newItem.id } : t))
    );
    setActiveTab('estimate');
  };

  // Estimate Handlers
  const handleUpdateEstimateItem = (updated: EstimateLineItem) => {
    setEstimateItems((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
  };

  const handleAddEstimateItem = (newItem: EstimateLineItem) => {
    setEstimateItems((prev) => [...prev, newItem]);
  };

  const handleDeleteEstimateItem = (id: string) => {
    setEstimateItems((prev) => prev.filter((item) => item.id !== id));
    // Unlink takeoff if any
    setTakeoffs((prev) =>
      prev.map((t) => (t.linkedEstimateItemId === id ? { ...t, linkedEstimateItemId: undefined } : t))
    );
  };

  const handlePushCostDbToEstimate = (item: CostDatabaseItem, quantity: number) => {
    const newItem: EstimateLineItem = {
      id: 'est-' + Date.now(),
      projectId: activeProject.id,
      divisionCode: item.divisionCode,
      divisionName: item.divisionName,
      itemCode: item.itemCode,
      description: item.description,
      quantity: quantity || 100,
      unit: item.unit,
      laborRate: item.laborRate,
      materialRate: item.materialRate,
      equipmentRate: item.equipmentRate,
      subcontractorRate: item.subcontractorRate,
      notes: item.notes,
    };
    setEstimateItems((prev) => [...prev, newItem]);
    setIsCostDbPickerOpen(false);
  };

  // Subcontractor Award Handler
  const handleAwardSub = (packageId: string, subId: string) => {
    const pkg = tradePackages.find((p) => p.id === packageId);
    const sub = subBids.find((s) => s.id === subId);
    if (!pkg || !sub) return;

    // 1. Mark sub as awarded, others in package as unawarded
    setSubBids((prev) =>
      prev.map((s) =>
        s.tradePackageId === packageId
          ? { ...s, isAwarded: s.id === subId }
          : s
      )
    );

    // 2. Mark package awardedSubId
    setTradePackages((prev) =>
      prev.map((p) => (p.id === packageId ? { ...p, awardedSubId: subId } : p))
    );

    // 3. Update or Insert line item in Master Estimate with the Subcontractor Rate!
    if (pkg.linkedEstimateItemId) {
      setEstimateItems((prev) =>
        prev.map((item) =>
          item.id === pkg.linkedEstimateItemId
            ? {
                ...item,
                subcontractorRate: sub.normalizedTotal,
                notes: `Awarded to ${sub.subName} ($${sub.normalizedTotal.toLocaleString()} normalized)`,
              }
            : item
        )
      );
    } else {
      // Create new line item
      const newLine: EstimateLineItem = {
        id: 'est-' + Date.now(),
        projectId: activeProject.id,
        divisionCode: pkg.divisionCode,
        divisionName: pkg.name,
        itemCode: `${pkg.divisionCode}-SUB`,
        description: `${pkg.name} - Awarded to ${sub.subName}`,
        quantity: 1,
        unit: 'LS',
        laborRate: 0,
        materialRate: 0,
        equipmentRate: 0,
        subcontractorRate: sub.normalizedTotal,
        notes: `Turnkey trade subcontract awarded to ${sub.subName}`,
      };
      setEstimateItems((prev) => [...prev, newLine]);
      setTradePackages((prev) =>
        prev.map((p) => (p.id === packageId ? { ...p, linkedEstimateItemId: newLine.id } : p))
      );
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-neutral-950 text-neutral-100 font-sans">
      {/* 1. Global Navigation Bar */}
      <Navigation
        activeTab={activeTab}
        onTabChange={setActiveTab}
        projects={projects}
        activeProject={activeProject}
        onSelectProject={setActiveProjectId}
        onOpenAiAssistant={() => setIsAiModalOpen(true)}
      />

      {/* 2. Sub-Header: Active Project Context Ribbon (Hidden during print) */}
      <div className="no-print h-9 bg-neutral-900/80 border-b border-neutral-800 px-6 flex items-center justify-between text-xs select-none shrink-0">
        <div className="flex items-center gap-4 text-neutral-400">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="font-bold text-neutral-200">{activeProject.name}</span>
          </div>
          <span>·</span>
          <div className="flex items-center gap-1 text-neutral-400">
            <Building2 className="w-3.5 h-3.5 text-neutral-500" />
            <span>{activeProject.client}</span>
          </div>
          <span>·</span>
          <div className="flex items-center gap-1 text-neutral-400">
            <MapPin className="w-3.5 h-3.5 text-neutral-500" />
            <span>{activeProject.location}</span>
          </div>
          <span>·</span>
          <div className="flex items-center gap-1 text-neutral-400">
            <Square className="w-3.5 h-3.5 text-neutral-500" />
            <span className="font-mono-numbers">{formatNumber(activeProject.squareFootage)} SF</span>
          </div>
          <span>·</span>
          <div className="flex items-center gap-1 text-neutral-400">
            <Calendar className="w-3.5 h-3.5 text-neutral-500" />
            <span>Due: <strong className="text-neutral-300 font-mono-numbers">{activeProject.bidDueDate}</strong></span>
          </div>
        </div>

        {/* Live Bid Price & Margin Snapshot */}
        <div className="flex items-center gap-4">
          <div className="text-neutral-400">
            Bid Price:{' '}
            <strong className="text-amber-400 font-mono-numbers">
              {formatCurrency(financials.grossBidTotal)}
            </strong>
          </div>
          <div className="text-neutral-400">
            GM:{' '}
            <strong className="text-emerald-400 font-mono-numbers">
              {financials.grossMarginPercent}%
            </strong>
          </div>
        </div>
      </div>

      {/* 3. Main Workspace Area */}
      <main className="flex-1 flex overflow-hidden">
        {/* Tab 1: Digital Takeoffs Canvas */}
        {activeTab === 'takeoffs' && (
          <TakeoffCanvas
            sheet={activeSheet}
            allSheets={planSheets.filter((s) => s.projectId === activeProject.id)}
            onSelectSheet={setActiveSheetId}
            takeoffs={takeoffs}
            onAddTakeoff={handleAddTakeoff}
            onUpdateTakeoff={handleUpdateTakeoff}
            onDeleteTakeoff={handleDeleteTakeoff}
            onUpdateSheetScale={handleUpdateSheetScale}
            estimateItems={projectEstimateItems}
            onLinkTakeoffToEstimate={handleLinkTakeoffToEstimate}
            onCreateEstimateFromTakeoff={handleCreateEstimateFromTakeoff}
          />
        )}

        {/* Tab 2: Master Estimate Spreadsheet & Financial Markup */}
        {activeTab === 'estimate' && (
          <div className="flex-1 flex h-full overflow-hidden">
            <EstimateSpreadsheet
              items={projectEstimateItems}
              project={activeProject}
              onUpdateItem={handleUpdateEstimateItem}
              onAddItem={handleAddEstimateItem}
              onDeleteItem={handleDeleteEstimateItem}
              onOpenCostDbModal={() => setIsCostDbPickerOpen(true)}
              onNavigateToTakeoffs={() => setActiveTab('takeoffs')}
            />
            <FinancialMarkupSidebar
              financials={financials}
              markupSettings={markupSettings}
              onUpdateMarkupSettings={setMarkupSettings}
              project={activeProject}
            />
          </div>
        )}

        {/* Tab 3: MasterFormat CSI Cost Database */}
        {activeTab === 'catalog' && (
          <CostCatalog
            items={costDatabase}
            onAddItem={(item) => setCostDatabase((prev) => [...prev, item])}
            onPushToEstimate={handlePushCostDbToEstimate}
            activeRegionKey={activeProject.regionFactorKey}
            onChangeRegion={(regKey) => {
              setProjects((prev) =>
                prev.map((p) => (p.id === activeProject.id ? { ...p, regionFactorKey: regKey } : p))
              );
            }}
          />
        )}

        {/* Tab 4: Subcontractor Bid Leveling Matrix */}
        {activeTab === 'subcontractors' && (
          <BidLevelingMatrix
            packages={tradePackages.filter((p) => p.projectId === activeProject.id)}
            subBids={subBids}
            estimateItems={projectEstimateItems}
            onAwardSub={handleAwardSub}
            onUpdateSubBid={(updated) =>
              setSubBids((prev) => prev.map((s) => (s.id === updated.id ? updated : s)))
            }
            onAddSubBid={(newBid) => setSubBids((prev) => [...prev, newBid])}
            onAddTradePackage={(newPkg) => setTradePackages((prev) => [...prev, newPkg])}
          />
        )}

        {/* Tab 5: Win / Loss Analytics */}
        {activeTab === 'analytics' && (
          <WinLossDashboard
            bids={historicalBids}
            onAddHistoricalBid={(bid) => setHistoricalBids((prev) => [bid, ...prev])}
          />
        )}

        {/* Tab 6: Formal Proposal & Print */}
        {activeTab === 'proposal' && (
          <ProposalGenerator
            project={activeProject}
            items={projectEstimateItems}
            financials={financials}
            onOpenAiVE={() => setIsAiModalOpen(true)}
          />
        )}
      </main>

      {/* Cost Database Picker Modal (Invoked from Estimate Spreadsheet) */}
      {isCostDbPickerOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-2xl w-full max-w-4xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-neutral-100 text-sm">
                  Select Items from CSI Cost Database
                </h3>
              </div>
              <button
                onClick={() => setIsCostDbPickerOpen(false)}
                className="text-neutral-400 hover:text-white text-xs px-2 py-1"
              >
                Close
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <CostCatalog
                items={costDatabase}
                onAddItem={(item) => setCostDatabase((prev) => [...prev, item])}
                onPushToEstimate={handlePushCostDbToEstimate}
                activeRegionKey={activeProject.regionFactorKey}
                onChangeRegion={(regKey) => {
                  setProjects((prev) =>
                    prev.map((p) => (p.id === activeProject.id ? { ...p, regionFactorKey: regKey } : p))
                  );
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* AI Estimator Copilot Modal */}
      <AiEstimatorModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        project={activeProject}
        estimateItems={projectEstimateItems}
        financials={financials}
        onAddEstimateItem={handleAddEstimateItem}
      />
    </div>
  );
}
