import { Point, EstimateLineItem, EstimateFinancials } from '../types';

/**
 * Calculates polygon area in square feet using Shoelace Formula
 * scaleRatio is pixels per foot.
 */
export function calculatePolygonAreaSF(points: Point[], scaleRatio: number): number {
  if (points.length < 3 || scaleRatio <= 0) return 0;

  let area = 0;
  const n = points.length;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    area += points[i].x * points[j].y;
    area -= points[j].x * points[i].y;
  }
  const pixelArea = Math.abs(area) / 2;
  const squareFeet = pixelArea / (scaleRatio * scaleRatio);
  return Math.round(squareFeet * 10) / 10;
}

/**
 * Calculates polyline length in linear feet
 */
export function calculatePolylineLengthLF(points: Point[], scaleRatio: number): number {
  if (points.length < 2 || scaleRatio <= 0) return 0;

  let pixelLength = 0;
  for (let i = 0; i < points.length - 1; i++) {
    const dx = points[i + 1].x - points[i].x;
    const dy = points[i + 1].y - points[i].y;
    pixelLength += Math.sqrt(dx * dx + dy * dy);
  }
  const linearFeet = pixelLength / scaleRatio;
  return Math.round(linearFeet * 10) / 10;
}

/**
 * Converts area SF and slab/pour thickness in inches to Cubic Yards (CY)
 */
export function calculateCubicYards(areaSF: number, thicknessInches: number = 4): number {
  const cubicFeet = areaSF * (thicknessInches / 12);
  const cubicYards = cubicFeet / 27;
  return Math.round(cubicYards * 10) / 10;
}

/**
 * Comprehensive contractor estimate cost buildup
 */
export function calculateEstimateFinancials(
  items: EstimateLineItem[],
  settings: {
    generalConditionsPercent: number;
    contingencyPercent: number;
    overheadPercent: number;
    targetProfitMarginPercent: number;
    bondRatePercent: number;
    insuranceRatePercent: number;
  },
  squareFootage: number = 10000,
  laborMultiplier: number = 1.0,
  materialMultiplier: number = 1.0
): EstimateFinancials {
  let directLaborTotal = 0;
  let directMaterialTotal = 0;
  let directEquipmentTotal = 0;
  let directSubcontractTotal = 0;

  for (const item of items) {
    const qty = Number(item.quantity) || 0;
    directLaborTotal += qty * (Number(item.laborRate) || 0) * laborMultiplier;
    directMaterialTotal += qty * (Number(item.materialRate) || 0) * materialMultiplier;
    directEquipmentTotal += qty * (Number(item.equipmentRate) || 0);
    directSubcontractTotal += qty * (Number(item.subcontractorRate) || 0);
  }

  const directCostTotal =
    directLaborTotal + directMaterialTotal + directEquipmentTotal + directSubcontractTotal;

  // General Conditions (% of direct costs)
  const generalConditionsAmount = directCostTotal * (settings.generalConditionsPercent / 100);

  // Contingency (% of direct + GC)
  const baseForContingency = directCostTotal + generalConditionsAmount;
  const contingencyAmount = baseForContingency * (settings.contingencyPercent / 100);

  // Overhead (% of direct + GC + Contingency)
  const baseForOverhead = baseForContingency + contingencyAmount;
  const overheadAmount = baseForOverhead * (settings.overheadPercent / 100);

  // Net Cost to contractor
  const netCostTotal = baseForOverhead + overheadAmount;

  // Contractor target profit markup
  const targetProfitMarginAmount = netCostTotal * (settings.targetProfitMarginPercent / 100);

  // Bond & Insurance on subtotal
  const baseForBondInsurance = netCostTotal + targetProfitMarginAmount;
  const bondAmount = baseForBondInsurance * (settings.bondRatePercent / 100);
  const insuranceAmount = baseForBondInsurance * (settings.insuranceRatePercent / 100);

  // Gross Bid Price
  const grossBidTotal = baseForBondInsurance + bondAmount + insuranceAmount;

  // Total gross profit (profit markup + contractor overhead recovery)
  const grossProfitTotal = targetProfitMarginAmount + overheadAmount;
  const grossMarginPercent = grossBidTotal > 0 ? (grossProfitTotal / grossBidTotal) * 100 : 0;
  const costPerSF = squareFootage > 0 ? grossBidTotal / squareFootage : 0;

  return {
    directLaborTotal: Math.round(directLaborTotal),
    directMaterialTotal: Math.round(directMaterialTotal),
    directEquipmentTotal: Math.round(directEquipmentTotal),
    directSubcontractTotal: Math.round(directSubcontractTotal),
    directCostTotal: Math.round(directCostTotal),

    generalConditionsPercent: settings.generalConditionsPercent,
    generalConditionsAmount: Math.round(generalConditionsAmount),
    contingencyPercent: settings.contingencyPercent,
    contingencyAmount: Math.round(contingencyAmount),
    overheadPercent: settings.overheadPercent,
    overheadAmount: Math.round(overheadAmount),

    netCostTotal: Math.round(netCostTotal),

    targetProfitMarginPercent: settings.targetProfitMarginPercent,
    targetProfitMarginAmount: Math.round(targetProfitMarginAmount),

    bondRatePercent: settings.bondRatePercent,
    bondAmount: Math.round(bondAmount),
    insuranceRatePercent: settings.insuranceRatePercent,
    insuranceAmount: Math.round(insuranceAmount),

    grossBidTotal: Math.round(grossBidTotal),
    grossProfitTotal: Math.round(grossProfitTotal),
    grossMarginPercent: Math.round(grossMarginPercent * 10) / 10,
    costPerSF: Math.round(costPerSF * 100) / 100,
  };
}

/**
 * Currency Formatter
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(amount || 0);
}

/**
 * Currency with cents
 */
export function formatCurrencyCents(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount || 0);
}

/**
 * Formats standard numbers with comma separators
 */
export function formatNumber(val: number, decimals: number = 0): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(val || 0);
}

/**
 * Formats percent
 */
export function formatPercent(val: number): string {
  return `${(val || 0).toFixed(1)}%`;
}
