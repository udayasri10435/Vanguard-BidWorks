import {
  Project,
  PlanSheet,
  TakeoffItem,
  CostDatabaseItem,
  EstimateLineItem,
  TradePackage,
  SubcontractorBid,
  HistoricalBid,
} from '../types';
import {
  initialProjects,
  initialPlanSheets,
  initialTakeoffItems,
  initialCostDatabase,
  initialEstimateItems,
  initialTradePackages,
  initialSubBids,
  initialHistoricalBids,
} from '../data/initialData';

const STORAGE_KEYS = {
  PROJECTS: 'vanguard_projects_v1',
  ACTIVE_PROJECT: 'vanguard_active_proj_v1',
  PLAN_SHEETS: 'vanguard_sheets_v1',
  TAKEOFFS: 'vanguard_takeoffs_v1',
  COST_DB: 'vanguard_costdb_v1',
  ESTIMATE_ITEMS: 'vanguard_estimate_items_v1',
  TRADE_PACKAGES: 'vanguard_packages_v1',
  SUB_BIDS: 'vanguard_sub_bids_v1',
  HISTORICAL_BIDS: 'vanguard_history_bids_v1',
  MARKUP_SETTINGS: 'vanguard_markup_settings_v1',
};

export interface MarkupSettings {
  generalConditionsPercent: number;
  contingencyPercent: number;
  overheadPercent: number;
  targetProfitMarginPercent: number;
  bondRatePercent: number;
  insuranceRatePercent: number;
}

export const defaultMarkupSettings: MarkupSettings = {
  generalConditionsPercent: 8.5,
  contingencyPercent: 5.0,
  overheadPercent: 7.5,
  targetProfitMarginPercent: 12.0,
  bondRatePercent: 1.25,
  insuranceRatePercent: 1.45,
};

function safeGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Failed to load key ${key} from storage:`, err);
    return fallback;
  }
}

function safeSet<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Failed to save key ${key} to storage:`, err);
  }
}

export const AppStorage = {
  getProjects: (): Project[] => safeGet(STORAGE_KEYS.PROJECTS, initialProjects),
  setProjects: (data: Project[]) => safeSet(STORAGE_KEYS.PROJECTS, data),

  getActiveProjectId: (): string => safeGet(STORAGE_KEYS.ACTIVE_PROJECT, 'proj-001'),
  setActiveProjectId: (id: string) => safeSet(STORAGE_KEYS.ACTIVE_PROJECT, id),

  getPlanSheets: (): PlanSheet[] => safeGet(STORAGE_KEYS.PLAN_SHEETS, initialPlanSheets),
  setPlanSheets: (data: PlanSheet[]) => safeSet(STORAGE_KEYS.PLAN_SHEETS, data),

  getTakeoffs: (): TakeoffItem[] => safeGet(STORAGE_KEYS.TAKEOFFS, initialTakeoffItems),
  setTakeoffs: (data: TakeoffItem[]) => safeSet(STORAGE_KEYS.TAKEOFFS, data),

  getCostDatabase: (): CostDatabaseItem[] => safeGet(STORAGE_KEYS.COST_DB, initialCostDatabase),
  setCostDatabase: (data: CostDatabaseItem[]) => safeSet(STORAGE_KEYS.COST_DB, data),

  getEstimateItems: (): EstimateLineItem[] => safeGet(STORAGE_KEYS.ESTIMATE_ITEMS, initialEstimateItems),
  setEstimateItems: (data: EstimateLineItem[]) => safeSet(STORAGE_KEYS.ESTIMATE_ITEMS, data),

  getTradePackages: (): TradePackage[] => safeGet(STORAGE_KEYS.TRADE_PACKAGES, initialTradePackages),
  setTradePackages: (data: TradePackage[]) => safeSet(STORAGE_KEYS.TRADE_PACKAGES, data),

  getSubBids: (): SubcontractorBid[] => safeGet(STORAGE_KEYS.SUB_BIDS, initialSubBids),
  setSubBids: (data: SubcontractorBid[]) => safeSet(STORAGE_KEYS.SUB_BIDS, data),

  getHistoricalBids: (): HistoricalBid[] => safeGet(STORAGE_KEYS.HISTORICAL_BIDS, initialHistoricalBids),
  setHistoricalBids: (data: HistoricalBid[]) => safeSet(STORAGE_KEYS.HISTORICAL_BIDS, data),

  getMarkupSettings: (): MarkupSettings => safeGet(STORAGE_KEYS.MARKUP_SETTINGS, defaultMarkupSettings),
  setMarkupSettings: (data: MarkupSettings) => safeSet(STORAGE_KEYS.MARKUP_SETTINGS, data),

  resetToDefaults: () => {
    localStorage.removeItem(STORAGE_KEYS.PROJECTS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_PROJECT);
    localStorage.removeItem(STORAGE_KEYS.PLAN_SHEETS);
    localStorage.removeItem(STORAGE_KEYS.TAKEOFFS);
    localStorage.removeItem(STORAGE_KEYS.COST_DB);
    localStorage.removeItem(STORAGE_KEYS.ESTIMATE_ITEMS);
    localStorage.removeItem(STORAGE_KEYS.TRADE_PACKAGES);
    localStorage.removeItem(STORAGE_KEYS.SUB_BIDS);
    localStorage.removeItem(STORAGE_KEYS.HISTORICAL_BIDS);
    localStorage.removeItem(STORAGE_KEYS.MARKUP_SETTINGS);
  },

  exportAllDataJSON: (): string => {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      projects: AppStorage.getProjects(),
      activeProjectId: AppStorage.getActiveProjectId(),
      planSheets: AppStorage.getPlanSheets(),
      takeoffs: AppStorage.getTakeoffs(),
      costDatabase: AppStorage.getCostDatabase(),
      estimateItems: AppStorage.getEstimateItems(),
      tradePackages: AppStorage.getTradePackages(),
      subBids: AppStorage.getSubBids(),
      historicalBids: AppStorage.getHistoricalBids(),
      markupSettings: AppStorage.getMarkupSettings(),
    };
    return JSON.stringify(backup, null, 2);
  },

  importAllDataJSON: (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.projects) AppStorage.setProjects(data.projects);
      if (data.activeProjectId) AppStorage.setActiveProjectId(data.activeProjectId);
      if (data.planSheets) AppStorage.setPlanSheets(data.planSheets);
      if (data.takeoffs) AppStorage.setTakeoffs(data.takeoffs);
      if (data.costDatabase) AppStorage.setCostDatabase(data.costDatabase);
      if (data.estimateItems) AppStorage.setEstimateItems(data.estimateItems);
      if (data.tradePackages) AppStorage.setTradePackages(data.tradePackages);
      if (data.subBids) AppStorage.setSubBids(data.subBids);
      if (data.historicalBids) AppStorage.setHistoricalBids(data.historicalBids);
      if (data.markupSettings) AppStorage.setMarkupSettings(data.markupSettings);
      return true;
    } catch (e) {
      console.error('Failed to import backup JSON', e);
      return false;
    }
  },
};
