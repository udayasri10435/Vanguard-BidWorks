import React, { useState } from 'react';
import { Project, EstimateLineItem, EstimateFinancials } from '../../types';
import { formatCurrency, formatNumber } from '../../utils/calculations';
import { Sparkles, X, Check, ArrowRight, ShieldAlert, Lightbulb, FileText, ChevronRight } from 'lucide-react';

interface AiEstimatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  estimateItems: EstimateLineItem[];
  financials: EstimateFinancials;
  onAddEstimateItem: (item: EstimateLineItem) => void;
}

export const AiEstimatorModal: React.FC<AiEstimatorModalProps> = ({
  isOpen,
  onClose,
  project,
  estimateItems,
  financials,
  onAddEstimateItem,
}) => {
  const [activeTab, setActiveTab] = useState<'ve' | 'scope' | 'letter'>('ve');

  // VE State
  const [isGeneratingVE, setIsGeneratingVE] = useState<boolean>(false);
  const [veResults, setVeResults] = useState<any>(null);

  // Scope State
  const [isAnalyzingScope, setIsAnalyzingScope] = useState<boolean>(false);
  const [scopeInput, setScopeInput] = useState<string>(
    project.notes || 'Full interior commercial office renovation: metal studs, drywall, acoustical ceilings, electrical switchgear, polished concrete, and high-efficiency rooftop HVAC RTUs.'
  );
  const [scopeResults, setScopeResults] = useState<any>(null);

  // Draft Letter State
  const [draftedLetter, setDraftedLetter] = useState<string>('');

  if (!isOpen) return null;

  // Run Value Engineering
  const handleGenerateVE = async () => {
    setIsGeneratingVE(true);
    try {
      const summary = estimateItems.map((i) => `${i.description} ($${(i.quantity * (i.laborRate + i.materialRate + i.equipmentRate + i.subcontractorRate)).toFixed(0)})`).join('; ');
      const res = await fetch('/api/ai/value-engineering', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentEstimateTotal: financials.grossBidTotal,
          lineItemsSummary: summary,
        }),
      });
      const data = await res.json();
      setVeResults(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingVE(false);
    }
  };

  // Run Scope Analysis
  const handleAnalyzeScope = async () => {
    setIsAnalyzingScope(true);
    try {
      const res = await fetch('/api/ai/analyze-scope', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectTitle: project.name,
          projectType: project.sector,
          squareFootage: project.squareFootage,
          scopeDescription: scopeInput,
        }),
      });
      const data = await res.json();
      setScopeResults(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzingScope(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-700 rounded-2xl w-full max-w-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-amber-500/10 rounded-lg border border-amber-500/20">
              <Sparkles className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-100 text-sm">
                AI Construction Estimator Copilot
              </h3>
              <p className="text-xs text-neutral-400">
                Powered by Gemini · Value engineering, spec gap detection & scope breakdown
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="px-4 pt-3 bg-neutral-900 border-b border-neutral-800 flex gap-2">
          <button
            onClick={() => setActiveTab('ve')}
            className={`px-3 py-2 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 've'
                ? 'bg-neutral-950 border-neutral-700 text-amber-400'
                : 'bg-neutral-900 border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Value Engineering (VE) Engine
          </button>
          <button
            onClick={() => setActiveTab('scope')}
            className={`px-3 py-2 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'scope'
                ? 'bg-neutral-950 border-neutral-700 text-amber-400'
                : 'bg-neutral-900 border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            RFP Scope & CSI Divisions
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 text-xs">
          {/* TAB 1: VALUE ENGINEERING */}
          {activeTab === 've' && (
            <div className="space-y-4">
              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-neutral-200 block">
                    Target Project: {project.name}
                  </span>
                  <span className="text-neutral-400">
                    Current Bid Total:{' '}
                    <strong className="text-amber-400 font-mono-numbers">
                      {formatCurrency(financials.grossBidTotal)}
                    </strong>
                  </span>
                </div>
                <button
                  disabled={isGeneratingVE}
                  onClick={handleGenerateVE}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isGeneratingVE ? 'Analyzing Specs...' : 'Generate VE Options'}</span>
                </button>
              </div>

              {veResults ? (
                <div className="space-y-3">
                  <div className="p-2.5 bg-emerald-950/40 border border-emerald-800/80 rounded-lg flex items-center justify-between">
                    <span className="font-bold text-emerald-300">
                      Total Potential Bid Savings Identified:
                    </span>
                    <span className="font-mono-numbers text-base font-extrabold text-emerald-400">
                      {formatCurrency(veResults.totalPotentialSavings || 54000)}
                    </span>
                  </div>

                  {veResults.ideas?.map((idea: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2 hover:border-neutral-700 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Lightbulb className="w-4 h-4 text-amber-400 shrink-0" />
                          <h4 className="font-bold text-neutral-100 text-xs">{idea.title}</h4>
                        </div>
                        <span className="font-mono-numbers text-xs font-bold text-emerald-400 shrink-0 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                          Save ~{formatCurrency(idea.estimatedSavings)}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-neutral-400 bg-neutral-900/60 p-2.5 rounded-lg">
                        <div>
                          <span className="font-semibold text-neutral-300 block mb-0.5">
                            Original Specification:
                          </span>
                          <p className="line-through opacity-80">{idea.originalSpec}</p>
                        </div>
                        <div>
                          <span className="font-semibold text-emerald-300 block mb-0.5">
                            Proposed Value Alternate:
                          </span>
                          <p className="text-neutral-200">{idea.proposedAlternate}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1">
                        <span>Schedule: {idea.scheduleImpact}</span>
                        <button
                          onClick={() => {
                            // Add VE credit line item to estimate
                            const creditItem: EstimateLineItem = {
                              id: 'est-ve-' + Date.now(),
                              projectId: project.id,
                              divisionCode: '01',
                              divisionName: 'General Requirements',
                              itemCode: `VE-ALT-${idx + 1}`,
                              description: `[VE Credit] ${idea.title}: ${idea.proposedAlternate}`,
                              quantity: 1,
                              unit: 'LS',
                              laborRate: 0,
                              materialRate: -Math.abs(idea.estimatedSavings),
                              equipmentRate: 0,
                              subcontractorRate: 0,
                              notes: 'Approved Value Engineering alternate substitution',
                            };
                            onAddEstimateItem(creditItem);
                            alert(`Added VE deduction of -${formatCurrency(idea.estimatedSavings)} to the Master Estimate!`);
                          }}
                          className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded border border-neutral-700 font-medium transition-colors"
                        >
                          + Apply Deduct to Bid
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center text-neutral-500">
                  <Lightbulb className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                  <p className="text-neutral-300 font-medium">Click &quot;Generate VE Options&quot; above.</p>
                  <p className="text-neutral-500 text-xs mt-1">
                    Gemini will inspect your current line items and propose cost-saving specification substitutions.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: RFP SCOPE & CSI DIVISIONS */}
          {activeTab === 'scope' && (
            <div className="space-y-4">
              <div>
                <label className="text-neutral-300 font-semibold block mb-1">
                  Architectural RFP Scope Summary / Project Narrative:
                </label>
                <textarea
                  rows={4}
                  value={scopeInput}
                  onChange={(e) => setScopeInput(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-3 text-xs text-neutral-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  disabled={isAnalyzingScope}
                  onClick={handleAnalyzeScope}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isAnalyzingScope ? 'Extracting Scopes...' : 'Extract CSI Divisions & Risks'}</span>
                </button>
              </div>

              {scopeResults && (
                <div className="space-y-4 pt-2">
                  <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800">
                    <span className="font-bold text-amber-400 block mb-1">Scope Executive Summary:</span>
                    <p className="text-neutral-300 leading-relaxed">{scopeResults.summary}</p>
                  </div>

                  <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800">
                    <span className="font-bold text-rose-400 flex items-center gap-1.5 mb-2">
                      <ShieldAlert className="w-4 h-4" />
                      Critical Risk Flags & Long-Lead Items
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-neutral-300">
                      {scopeResults.riskFlags?.map((rf: string, i: number) => (
                        <li key={i}>{rf}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <span className="font-bold text-neutral-200 block">Recommended CSI Divisions:</span>
                    {scopeResults.recommendedDivisions?.map((div: any, i: number) => (
                      <div
                        key={i}
                        className="p-3 bg-neutral-950 rounded-lg border border-neutral-800 space-y-2"
                      >
                        <span className="font-bold text-amber-400">
                          Division {div.divisionCode} - {div.divisionName}
                        </span>
                        <div className="space-y-1.5">
                          {div.suggestedItems?.map((sItem: any, idx: number) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between text-neutral-300 bg-neutral-900/60 p-1.5 rounded"
                            >
                              <div>
                                <span className="font-mono-numbers text-neutral-400 mr-2">
                                  {sItem.itemCode}
                                </span>
                                <span>{sItem.description}</span>
                                <span className="text-neutral-500 ml-2">
                                  ({sItem.approxQty} {sItem.unit} @ ${sItem.estimatedUnitCost})
                                </span>
                              </div>
                              <button
                                onClick={() => {
                                  onAddEstimateItem({
                                    id: 'est-ai-' + Date.now() + '-' + idx,
                                    projectId: project.id,
                                    divisionCode: div.divisionCode,
                                    divisionName: div.divisionName,
                                    itemCode: sItem.itemCode,
                                    description: sItem.description,
                                    quantity: sItem.approxQty,
                                    unit: sItem.unit,
                                    laborRate: Math.round(sItem.estimatedUnitCost * 0.5 * 100) / 100,
                                    materialRate: Math.round(sItem.estimatedUnitCost * 0.5 * 100) / 100,
                                    equipmentRate: 0,
                                    subcontractorRate: 0,
                                  });
                                  alert(`Added ${sItem.description} to Master Estimate!`);
                                }}
                                className="px-2 py-0.5 bg-neutral-800 hover:bg-amber-600 hover:text-white rounded text-[11px] font-medium"
                              >
                                + Add Item
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
