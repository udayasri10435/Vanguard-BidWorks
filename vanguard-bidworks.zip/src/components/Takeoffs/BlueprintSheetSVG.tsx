import React from 'react';
import { PlanSheet } from '../../types';

interface BlueprintSheetSVGProps {
  sheet: PlanSheet;
}

export const BlueprintSheetSVG: React.FC<BlueprintSheetSVGProps> = ({ sheet }) => {
  const { width, height } = sheet.dimensions;

  // Custom image fallback or template
  if (sheet.customImageUrl) {
    return (
      <image
        href={sheet.customImageUrl}
        width={width}
        height={height}
        preserveAspectRatio="xMidYMid meet"
      />
    );
  }

  return (
    <g className="blueprint-layer select-none pointer-events-none">
      {/* Background drafting paper */}
      <rect x="0" y="0" width={width} height={height} fill="#131b26" />

      {/* CAD Grid Pattern */}
      <defs>
        <pattern id="cadGrid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.75" />
        </pattern>
        <pattern id="cadGridDense" width="10" height="10" patternUnits="userSpaceOnUse">
          <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#172233" strokeWidth="0.5" strokeOpacity="0.4" />
        </pattern>
      </defs>

      <rect x="0" y="0" width={width} height={height} fill="url(#cadGridDense)" />
      <rect x="0" y="0" width={width} height={height} fill="url(#cadGrid)" />

      {/* Architectural Border & Title Block */}
      <rect
        x="40"
        y="40"
        width={width - 80}
        height={height - 80}
        fill="none"
        stroke="#334155"
        strokeWidth="2"
      />
      <rect
        x="44"
        y="44"
        width={width - 88}
        height={height - 88}
        fill="none"
        stroke="#1e293b"
        strokeWidth="1"
      />

      {/* Title Block Bottom-Right */}
      <g transform={`translate(${width - 360}, ${height - 130})`}>
        <rect width="310" height="80" fill="#0f172a" stroke="#475569" strokeWidth="1" />
        <line x1="0" y1="26" x2="310" y2="26" stroke="#334155" strokeWidth="1" />
        <line x1="0" y1="52" x2="310" y2="52" stroke="#334155" strokeWidth="1" />
        <line x1="160" y1="26" x2="160" y2="80" stroke="#334155" strokeWidth="1" />

        <text x="12" y="18" fill="#e2e8f0" fontSize="12" fontWeight="700" letterSpacing="1">
          {sheet.name.toUpperCase()}
        </text>
        <text x="12" y="42" fill="#94a3b8" fontSize="10">SCALE: {sheet.scaleLabel}</text>
        <text x="12" y="68" fill="#94a3b8" fontSize="10">REV: B (BID SET)</text>
        <text x="172" y="42" fill="#94a3b8" fontSize="10">DATE: 2026-09-15</text>
        <text x="172" y="68" fill="#38bdf8" fontSize="14" fontWeight="800">
          SHEET: {sheet.sheetNumber}
        </text>
      </g>

      {/* North Arrow */}
      <g transform="translate(90, 90)">
        <circle cx="0" cy="0" r="22" fill="#0f172a" stroke="#475569" strokeWidth="1.5" />
        <polygon points="0,-18 5,0 0,-4 -5,0" fill="#38bdf8" />
        <polygon points="0,18 5,0 0,4 -5,0" fill="#475569" />
        <text x="-4" y="-22" fill="#e2e8f0" fontSize="11" fontWeight="700">N</text>
      </g>

      {/* RENDER TEMPLATE GEOMETRY */}
      {sheet.svgTemplate === 'commercial_floorplan' && (
        <g className="commercial-layout">
          {/* Column Grid Lines */}
          <g stroke="#334155" strokeWidth="1" strokeDasharray="6,4">
            <line x1="120" y1="90" x2="120" y2="760" />
            <line x1="420" y1="90" x2="420" y2="760" />
            <line x1="740" y1="90" x2="740" y2="760" />
            <line x1="1050" y1="90" x2="1050" y2="760" />

            <line x1="90" y1="150" x2="1100" y2="150" />
            <line x1="90" y1="380" x2="1100" y2="380" />
            <line x1="90" y1="550" x2="1100" y2="550" />
            <line x1="90" y1="720" x2="1100" y2="720" />
          </g>

          {/* Grid Bubbles */}
          <g fill="#0f172a" stroke="#64748b" strokeWidth="1">
            <circle cx="120" cy="80" r="12" /><text x="116" y="84" fill="#cbd5e1" fontSize="11">A</text>
            <circle cx="420" cy="80" r="12" /><text x="416" y="84" fill="#cbd5e1" fontSize="11">B</text>
            <circle cx="740" cy="80" r="12" /><text x="736" y="84" fill="#cbd5e1" fontSize="11">C</text>
            <circle cx="1050" cy="80" r="12" /><text x="1046" y="84" fill="#cbd5e1" fontSize="11">D</text>

            <circle cx="70" cy="150" r="12" /><text x="67" y="154" fill="#cbd5e1" fontSize="11">1</text>
            <circle cx="70" cy="380" r="12" /><text x="67" y="384" fill="#cbd5e1" fontSize="11">2</text>
            <circle cx="70" cy="550" r="12" /><text x="67" y="554" fill="#cbd5e1" fontSize="11">3</text>
            <circle cx="70" cy="720" r="12" /><text x="67" y="724" fill="#cbd5e1" fontSize="11">4</text>
          </g>

          {/* Exterior Building Perimeter Walls */}
          <rect
            x="120"
            y="150"
            width="930"
            height="570"
            fill="none"
            stroke="#94a3b8"
            strokeWidth="5"
          />

          {/* Interior Partitions */}
          {/* Reception / Lobby boundary */}
          <line x1="420" y1="150" x2="420" y2="380" stroke="#cbd5e1" strokeWidth="3" />
          <line x1="120" y1="380" x2="420" y2="380" stroke="#cbd5e1" strokeWidth="3" />

          {/* Conference Rooms */}
          <line x1="120" y1="550" x2="420" y2="550" stroke="#cbd5e1" strokeWidth="3" />
          <line x1="270" y1="380" x2="270" y2="550" stroke="#cbd5e1" strokeWidth="3" />

          {/* Breakroom & Restrooms */}
          <line x1="120" y1="640" x2="420" y2="640" stroke="#cbd5e1" strokeWidth="3" />

          {/* Open Collaboration Area demising line */}
          <line x1="420" y1="550" x2="1050" y2="550" stroke="#cbd5e1" strokeWidth="3" />
          <line x1="740" y1="550" x2="740" y2="720" stroke="#cbd5e1" strokeWidth="3" />
          <line x1="890" y1="550" x2="890" y2="720" stroke="#cbd5e1" strokeWidth="3" />

          {/* Door Swings */}
          {/* Main Entrance Double Door */}
          <g stroke="#38bdf8" strokeWidth="1.5" fill="none">
            <line x1="120" y1="240" x2="120" y2="290" stroke="#0f172a" strokeWidth="6" />
            <path d="M 120 240 A 25 25 0 0 1 145 265" strokeDasharray="3,2" />
            <line x1="120" y1="240" x2="145" y2="240" />
            <path d="M 120 290 A 25 25 0 0 0 145 265" strokeDasharray="3,2" />
            <line x1="120" y1="290" x2="145" y2="290" />
          </g>

          {/* Interior Doors */}
          <g stroke="#64748b" strokeWidth="1.2" fill="none">
            {/* Conf A */}
            <path d="M 270 410 A 30 30 0 0 1 300 440" strokeDasharray="3,2" />
            <line x1="270" y1="410" x2="300" y2="410" />
            {/* Conf B */}
            <path d="M 270 510 A 30 30 0 0 0 300 480" strokeDasharray="3,2" />
            <line x1="270" y1="510" x2="300" y2="510" />
            {/* Breakroom */}
            <path d="M 420 600 A 30 30 0 0 1 450 630" strokeDasharray="3,2" />
            <line x1="420" y1="600" x2="450" y2="600" />
          </g>

          {/* Room Labels */}
          <text x="210" y="270" fill="#94a3b8" fontSize="13" fontWeight="600" textAnchor="middle">
            LOBBY & RECEPTION
          </text>
          <text x="210" y="290" fill="#64748b" fontSize="11" textAnchor="middle">
            101 · 1,250 SF
          </text>

          <text x="195" y="470" fill="#94a3b8" fontSize="12" fontWeight="600" textAnchor="middle">
            CONF ROOM A
          </text>
          <text x="195" y="488" fill="#64748b" fontSize="10" textAnchor="middle">
            102 · 480 SF
          </text>

          <text x="345" y="470" fill="#94a3b8" fontSize="12" fontWeight="600" textAnchor="middle">
            CONF ROOM B
          </text>
          <text x="345" y="488" fill="#64748b" fontSize="10" textAnchor="middle">
            103 · 520 SF
          </text>

          <text x="735" y="340" fill="#94a3b8" fontSize="16" fontWeight="700" textAnchor="middle" letterSpacing="1">
            OPEN COLLABORATION & WORKSTATIONS
          </text>
          <text x="735" y="365" fill="#64748b" fontSize="12" textAnchor="middle">
            104 · 4,250 SF · 48 STATIONS
          </text>

          <text x="270" y="685" fill="#94a3b8" fontSize="12" fontWeight="600" textAnchor="middle">
            CAFÉ & PANTRY
          </text>

          <text x="815" y="640" fill="#94a3b8" fontSize="12" fontWeight="600" textAnchor="middle">
            RESTROOMS (M/W)
          </text>

          <text x="970" y="640" fill="#94a3b8" fontSize="12" fontWeight="600" textAnchor="middle">
            SERVER LAB / IT
          </text>

          {/* Dimension Strings */}
          <g stroke="#0284c7" strokeWidth="1" fill="none">
            <line x1="120" y1="120" x2="420" y2="120" />
            <line x1="120" y1="115" x2="120" y2="125" strokeWidth="1.5" />
            <line x1="420" y1="115" x2="420" y2="125" strokeWidth="1.5" />
            <text x="270" y="112" fill="#38bdf8" fontSize="11" textAnchor="middle" fontWeight="600">
              30'-0"
            </text>

            <line x1="420" y1="120" x2="1050" y2="120" />
            <line x1="1050" y1="115" x2="1050" y2="125" strokeWidth="1.5" />
            <text x="735" y="112" fill="#38bdf8" fontSize="11" textAnchor="middle" fontWeight="600">
              63'-0"
            </text>
          </g>
        </g>
      )}

      {sheet.svgTemplate === 'foundation_plan' && (
        <g className="foundation-layout">
          {/* Continuous Footing Perimeter */}
          <rect
            x="120"
            y="150"
            width="930"
            height="570"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="8"
            strokeDasharray="12,6"
          />

          {/* Slab sawcuts / control joints */}
          <g stroke="#475569" strokeWidth="1" strokeDasharray="4,4">
            <line x1="120" y1="300" x2="1050" y2="300" />
            <line x1="120" y1="450" x2="1050" y2="450" />
            <line x1="120" y1="600" x2="1050" y2="600" />
            <line x1="350" y1="150" x2="350" y2="720" />
            <line x1="580" y1="150" x2="580" y2="720" />
            <line x1="810" y1="150" x2="810" y2="720" />
          </g>

          {/* Column Footing Pads (F1) */}
          {[
            { x: 350, y: 300 },
            { x: 580, y: 300 },
            { x: 810, y: 300 },
            { x: 350, y: 450 },
            { x: 580, y: 450 },
            { x: 810, y: 450 },
            { x: 350, y: 600 },
            { x: 580, y: 600 },
            { x: 810, y: 600 },
          ].map((col, idx) => (
            <g key={idx} transform={`translate(${col.x}, ${col.y})`}>
              <rect x="-24" y="-24" width="48" height="48" fill="#1e293b" stroke="#f59e0b" strokeWidth="2" />
              <circle cx="0" cy="0" r="6" fill="#f59e0b" />
              <text x="30" y="4" fill="#fbbf24" fontSize="10" fontWeight="600">
                F1 (6'-0" x 6'-0")
              </text>
            </g>
          ))}

          <text x="585" y="240" fill="#fbbf24" fontSize="14" fontWeight="700" textAnchor="middle">
            5" CONCRETE SLAB-ON-GRADE (4,000 PSI) W/ #4 REBAR @ 12" O.C. BOTH WAYS
          </text>
          <text x="585" y="265" fill="#94a3b8" fontSize="11" textAnchor="middle">
            15-MIL VAPOR BARRIER OVER 4" COMPACTED CRUSHED AGGREGATE BASE
          </text>
        </g>
      )}

      {sheet.svgTemplate === 'mep_plan' && (
        <g className="mep-layout">
          {/* Ceiling Grid 2x4 */}
          <defs>
            <pattern id="ceilingGrid" width="48" height="24" patternUnits="userSpaceOnUse">
              <rect width="48" height="24" fill="none" stroke="#243247" strokeWidth="0.6" />
            </pattern>
          </defs>
          <rect x="120" y="150" width="930" height="570" fill="url(#ceilingGrid)" />

          {/* Building Boundary */}
          <rect x="120" y="150" width="930" height="570" fill="none" stroke="#64748b" strokeWidth="3" />

          {/* Electrical Panelboard */}
          <g transform="translate(140, 170)">
            <rect width="40" height="20" fill="#0f172a" stroke="#8b5cf6" strokeWidth="2" />
            <text x="4" y="14" fill="#a78bfa" fontSize="9" fontWeight="700">MDP</text>
          </g>

          {/* HVAC Ductwork Runs */}
          <g stroke="#10b981" strokeWidth="4" strokeLinecap="round" fill="none">
            <line x1="500" y1="200" x2="950" y2="200" />
            <line x1="720" y1="200" x2="720" y2="600" />
            <line x1="720" y1="400" x2="950" y2="400" />
            <line x1="720" y1="400" x2="300" y2="400" />
          </g>

          {/* Diffuser Markers */}
          {[
            { x: 550, y: 200 },
            { x: 750, y: 200 },
            { x: 900, y: 200 },
            { x: 400, y: 400 },
            { x: 600, y: 400 },
            { x: 850, y: 400 },
          ].map((d, i) => (
            <g key={i} transform={`translate(${d.x}, ${d.y})`}>
              <circle cx="0" cy="0" r="10" fill="#064e3b" stroke="#10b981" strokeWidth="1.5" />
              <line x1="-7" y1="0" x2="7" y2="0" stroke="#34d399" strokeWidth="1" />
              <line x1="0" y1="-7" x2="0" y2="7" stroke="#34d399" strokeWidth="1" />
            </g>
          ))}

          {/* Lighting Troffers */}
          {[
            { x: 520, y: 220 },
            { x: 620, y: 220 },
            { x: 720, y: 220 },
            { x: 820, y: 220 },
            { x: 920, y: 220 },
            { x: 520, y: 320 },
            { x: 620, y: 320 },
            { x: 720, y: 320 },
            { x: 820, y: 320 },
            { x: 920, y: 320 },
            { x: 520, y: 420 },
            { x: 620, y: 420 },
            { x: 720, y: 420 },
            { x: 820, y: 420 },
            { x: 920, y: 420 },
          ].map((troffer, index) => (
            <g key={index} transform={`translate(${troffer.x}, ${troffer.y})`}>
              <rect
                x="-16"
                y="-8"
                width="32"
                height="16"
                fill="#1e1b4b"
                stroke="#8b5cf6"
                strokeWidth="1.2"
              />
              <line x1="-16" y1="-8" x2="16" y2="8" stroke="#a78bfa" strokeWidth="0.8" />
              <line x1="-16" y1="8" x2="16" y2="-8" stroke="#a78bfa" strokeWidth="0.8" />
            </g>
          ))}

          <text x="735" y="180" fill="#10b981" fontSize="12" fontWeight="600" textAnchor="middle">
            18"x12" LOW-PRESSURE SUPPLY AIR DUCTWORK (SMACNA + R-6 LINER)
          </text>
        </g>
      )}
    </g>
  );
};
