import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  PlanSheet,
  TakeoffItem,
  Point,
  TakeoffToolType,
  EstimateLineItem,
} from '../../types';
import { BlueprintSheetSVG } from './BlueprintSheetSVG';
import {
  calculatePolygonAreaSF,
  calculatePolylineLengthLF,
  formatNumber,
} from '../../utils/calculations';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Hand,
  Square,
  Ruler,
  Hash,
  Compass,
  Plus,
  Trash2,
  Link as LinkIcon,
  Check,
  Layers,
  Settings2,
} from 'lucide-react';

interface TakeoffCanvasProps {
  sheet: PlanSheet;
  allSheets: PlanSheet[];
  onSelectSheet: (sheetId: string) => void;
  takeoffs: TakeoffItem[];
  onAddTakeoff: (item: TakeoffItem) => void;
  onUpdateTakeoff: (item: TakeoffItem) => void;
  onDeleteTakeoff: (id: string) => void;
  onUpdateSheetScale: (sheetId: string, newRatio: number, label: string) => void;
  estimateItems: EstimateLineItem[];
  onLinkTakeoffToEstimate: (takeoff: TakeoffItem, estimateItemId: string) => void;
  onCreateEstimateFromTakeoff: (takeoff: TakeoffItem, itemCode: string) => void;
}

const PRESET_COLORS = [
  '#0ea5e9', // Sky blue
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#8b5cf6', // Violet
  '#f43f5e', // Rose
  '#06b6d4', // Cyan
];

export const TakeoffCanvas: React.FC<TakeoffCanvasProps> = ({
  sheet,
  allSheets,
  onSelectSheet,
  takeoffs,
  onAddTakeoff,
  onUpdateTakeoff,
  onDeleteTakeoff,
  onUpdateSheetScale,
  estimateItems,
  onLinkTakeoffToEstimate,
  onCreateEstimateFromTakeoff,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Viewport transforms
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<Point>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<Point>({ x: 0, y: 0 });

  // Tool states: 'pan' | 'area' | 'linear' | 'count' | 'calibrate'
  const [activeTool, setActiveTool] = useState<TakeoffToolType | 'pan' | 'calibrate'>('pan');
  const [activeColor, setActiveColor] = useState<string>(PRESET_COLORS[0]);

  // In-progress points
  const [currentPoints, setCurrentPoints] = useState<Point[]>([]);
  const [hoverPoint, setHoverPoint] = useState<Point | null>(null);

  // Selection
  const [selectedTakeoffId, setSelectedTakeoffId] = useState<string | null>(null);

  // Calibration modal
  const [isCalibrateModalOpen, setIsCalibrateModalOpen] = useState<boolean>(false);
  const [calibrationPixelDistance, setCalibrationPixelDistance] = useState<number>(0);
  const [realDistanceFeet, setRealDistanceFeet] = useState<string>('20');

  // Link to Estimate modal
  const [linkingTakeoff, setLinkingTakeoff] = useState<TakeoffItem | null>(null);
  const [selectedEstimateId, setSelectedEstimateId] = useState<string>('');

  // Items for this sheet
  const sheetTakeoffs = takeoffs.filter((t) => t.sheetId === sheet.id);

  // Get mouse coordinates relative to SVG world space
  const getSVGCoordinates = useCallback(
    (e: React.MouseEvent<SVGSVGElement>): Point | null => {
      if (!svgRef.current) return null;
      const rect = svgRef.current.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;
      // Reverse pan and zoom
      const worldX = (clientX - pan.x) / zoom;
      const worldY = (clientY - pan.y) / zoom;
      return { x: Math.round(worldX), y: Math.round(worldY) };
    },
    [pan, zoom]
  );

  // Handle Wheel Zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    const newZoom = Math.min(Math.max(zoom * zoomFactor, 0.4), 4.0);
    setZoom(newZoom);
  };

  // Mouse Down
  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    // Middle click or Pan tool initiates dragging
    if (e.button === 1 || activeTool === 'pan' || e.altKey || e.shiftKey) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      return;
    }

    if (e.button !== 0) return; // Only left click for drawing
    const pt = getSVGCoordinates(e);
    if (!pt) return;

    if (activeTool === 'count') {
      // Direct stamp
      const newItem: TakeoffItem = {
        id: 'tk-' + Date.now(),
        projectId: sheet.projectId,
        sheetId: sheet.id,
        name: `Count Item (${sheetTakeoffs.length + 1})`,
        divisionCode: '26',
        toolType: 'count',
        points: [pt],
        measurementValue: 1,
        unit: 'EA',
        color: activeColor,
      };
      onAddTakeoff(newItem);
      setSelectedTakeoffId(newItem.id);
      return;
    }

    if (activeTool === 'calibrate') {
      const nextPts = [...currentPoints, pt];
      if (nextPts.length === 2) {
        // Compute pixel distance
        const dx = nextPts[1].x - nextPts[0].x;
        const dy = nextPts[1].y - nextPts[0].y;
        const pxDist = Math.sqrt(dx * dx + dy * dy);
        setCalibrationPixelDistance(pxDist);
        setIsCalibrateModalOpen(true);
        setCurrentPoints([]);
        setActiveTool('pan');
      } else {
        setCurrentPoints(nextPts);
      }
      return;
    }

    if (activeTool === 'area' || activeTool === 'linear') {
      setCurrentPoints((prev) => [...prev, pt]);
    }
  };

  // Mouse Move
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
      return;
    }

    const pt = getSVGCoordinates(e);
    if (pt) {
      setHoverPoint(pt);
    }
  };

  // Mouse Up
  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // Double Click finishes current polygon or line
  const handleDoubleClick = () => {
    if (currentPoints.length < 2) return;

    if (activeTool === 'area') {
      if (currentPoints.length < 3) return;
      const areaSF = calculatePolygonAreaSF(currentPoints, sheet.scaleRatio);
      const newItem: TakeoffItem = {
        id: 'tk-' + Date.now(),
        projectId: sheet.projectId,
        sheetId: sheet.id,
        name: `Area Zone (${sheetTakeoffs.length + 1})`,
        divisionCode: '09',
        toolType: 'area',
        points: currentPoints,
        measurementValue: areaSF,
        unit: 'SF',
        depthInches: 4,
        color: activeColor,
      };
      onAddTakeoff(newItem);
      setSelectedTakeoffId(newItem.id);
      setCurrentPoints([]);
      setActiveTool('pan');
    } else if (activeTool === 'linear') {
      const lengthLF = calculatePolylineLengthLF(currentPoints, sheet.scaleRatio);
      const newItem: TakeoffItem = {
        id: 'tk-' + Date.now(),
        projectId: sheet.projectId,
        sheetId: sheet.id,
        name: `Linear Run (${sheetTakeoffs.length + 1})`,
        divisionCode: '09',
        toolType: 'linear',
        points: currentPoints,
        measurementValue: lengthLF,
        unit: 'LF',
        heightFeet: 12,
        color: activeColor,
      };
      onAddTakeoff(newItem);
      setSelectedTakeoffId(newItem.id);
      setCurrentPoints([]);
      setActiveTool('pan');
    }
  };

  // Finalize Calibration
  const applyCalibration = () => {
    const feet = parseFloat(realDistanceFeet);
    if (feet > 0 && calibrationPixelDistance > 0) {
      const newRatio = calibrationPixelDistance / feet;
      onUpdateSheetScale(sheet.id, Math.round(newRatio * 10) / 10, `Calibrated (${feet} ft)`);
    }
    setIsCalibrateModalOpen(false);
  };

  // Live in-progress readout
  let liveReadout = '';
  if (currentPoints.length > 0 && hoverPoint) {
    const pts = [...currentPoints, hoverPoint];
    if (activeTool === 'area' && pts.length >= 3) {
      const sf = calculatePolygonAreaSF(pts, sheet.scaleRatio);
      liveReadout = `${formatNumber(sf)} SF`;
    } else if (activeTool === 'linear') {
      const lf = calculatePolylineLengthLF(pts, sheet.scaleRatio);
      liveReadout = `${formatNumber(lf, 1)} LF`;
    } else if (activeTool === 'calibrate') {
      liveReadout = 'Click second reference point';
    }
  }

  const selectedTakeoff = takeoffs.find((t) => t.id === selectedTakeoffId);

  return (
    <div className="flex flex-col h-full bg-neutral-950 text-neutral-100 select-none">
      {/* Top Sheet Toolbar */}
      <div className="h-12 border-b border-neutral-800 bg-neutral-900 px-4 flex items-center justify-between gap-4">
        {/* Sheet Selector */}
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-500" />
          <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">Plan Sheet:</span>
          <select
            value={sheet.id}
            onChange={(e) => onSelectSheet(e.target.value)}
            className="bg-neutral-800 border border-neutral-700 text-xs font-medium text-neutral-200 rounded px-2.5 py-1 focus:outline-none focus:border-amber-500"
          >
            {allSheets.map((s) => (
              <option key={s.id} value={s.id}>
                {s.sheetNumber} - {s.name} ({s.scaleLabel})
              </option>
            ))}
          </select>

          <span className="text-xs text-neutral-500 ml-2">
            Scale: <strong className="text-neutral-300 font-mono-numbers">{sheet.scaleLabel}</strong> ({sheet.scaleRatio} px/ft)
          </span>
        </div>

        {/* Measurement Tool Palette */}
        <div className="flex items-center gap-1 bg-neutral-800/80 p-1 rounded-lg border border-neutral-700/60">
          <button
            onClick={() => {
              setActiveTool('pan');
              setCurrentPoints([]);
            }}
            title="Pan / Navigate (Hand)"
            className={`p-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
              activeTool === 'pan'
                ? 'bg-neutral-700 text-white font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Hand className="w-4 h-4" />
            <span>Pan</span>
          </button>

          <div className="w-px h-4 bg-neutral-700 mx-0.5" />

          <button
            onClick={() => {
              setActiveTool('area');
              setCurrentPoints([]);
            }}
            title="Area Takeoff (Polygon SF)"
            className={`p-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
              activeTool === 'area'
                ? 'bg-sky-600 text-white font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Square className="w-4 h-4" />
            <span>Area (SF)</span>
          </button>

          <button
            onClick={() => {
              setActiveTool('linear');
              setCurrentPoints([]);
            }}
            title="Linear Takeoff (Polyline LF)"
            className={`p-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
              activeTool === 'linear'
                ? 'bg-amber-600 text-white font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Ruler className="w-4 h-4" />
            <span>Linear (LF)</span>
          </button>

          <button
            onClick={() => {
              setActiveTool('count');
              setCurrentPoints([]);
            }}
            title="Count Takeoff (Stamps EA)"
            className={`p-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
              activeTool === 'count'
                ? 'bg-violet-600 text-white font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Hash className="w-4 h-4" />
            <span>Count (EA)</span>
          </button>

          <div className="w-px h-4 bg-neutral-700 mx-0.5" />

          <button
            onClick={() => {
              setActiveTool('calibrate');
              setCurrentPoints([]);
            }}
            title="Calibrate Scale (Click 2 known points)"
            className={`p-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
              activeTool === 'calibrate'
                ? 'bg-rose-600 text-white font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Calibrate</span>
          </button>
        </div>

        {/* Color Palette & Zoom Controls */}
        <div className="flex items-center gap-3">
          {/* Colors */}
          <div className="flex items-center gap-1 bg-neutral-800 p-1 rounded border border-neutral-700">
            {PRESET_COLORS.map((col) => (
              <button
                key={col}
                onClick={() => setActiveColor(col)}
                className={`w-4 h-4 rounded-full transition-transform ${
                  activeColor === col ? 'scale-125 ring-2 ring-white' : 'opacity-80 hover:opacity-100'
                }`}
                style={{ backgroundColor: col }}
              />
            ))}
          </div>

          {/* Zoom */}
          <div className="flex items-center gap-1 bg-neutral-800 p-0.5 rounded border border-neutral-700">
            <button
              onClick={() => setZoom((z) => Math.max(z * 0.85, 0.4))}
              className="p-1 text-neutral-400 hover:text-white"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono-numbers px-1.5 text-neutral-300 w-11 text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => setZoom((z) => Math.min(z * 1.15, 4.0))}
              className="p-1 text-neutral-400 hover:text-white"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setZoom(1);
                setPan({ x: 0, y: 0 });
              }}
              className="p-1 text-neutral-400 hover:text-white"
              title="Fit View"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Viewport + Takeoff Ledger Sidebar */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Canvas Area */}
        <div
          ref={containerRef}
          className="flex-1 h-full overflow-hidden bg-neutral-950 relative cursor-crosshair"
          onWheel={handleWheel}
        >
          {/* Help Overlay Banner */}
          {activeTool !== 'pan' && (
            <div className="absolute top-3 left-3 z-10 bg-neutral-900/90 backdrop-blur border border-neutral-700 text-xs px-3 py-1.5 rounded-md shadow-lg flex items-center gap-3">
              <span className="font-semibold text-amber-400">
                {activeTool === 'area' && 'Drawing Area Polygon: Click vertices to shape zone. Double-click to close.'}
                {activeTool === 'linear' && 'Drawing Linear Path: Click points along wall or conduit. Double-click to finish.'}
                {activeTool === 'count' && 'Count Stamp: Click anywhere on plan to drop a count marker.'}
                {activeTool === 'calibrate' && 'Click 2 points across a known dimension string (e.g. 20ft room span).'}
              </span>
              {liveReadout && (
                <span className="bg-neutral-800 font-mono-numbers px-2 py-0.5 rounded text-sky-400 font-bold border border-neutral-700">
                  {liveReadout}
                </span>
              )}
              {currentPoints.length > 0 && (
                <button
                  onClick={() => setCurrentPoints([])}
                  className="text-neutral-400 hover:text-rose-400 text-xs underline"
                >
                  Cancel
                </button>
              )}
            </div>
          )}

          <svg
            ref={svgRef}
            className="w-full h-full select-none"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onDoubleClick={handleDoubleClick}
          >
            <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
              {/* Architectural CAD Blueprint Base */}
              <BlueprintSheetSVG sheet={sheet} />

              {/* RENDER EXISTING TAKEOFFS ON THIS SHEET */}
              {sheetTakeoffs.map((item) => {
                const isSelected = item.id === selectedTakeoffId;

                if (item.toolType === 'area') {
                  const pointsStr = item.points.map((p) => `${p.x},${p.y}`).join(' ');
                  // Center for label
                  const avgX = item.points.reduce((acc, p) => acc + p.x, 0) / item.points.length;
                  const avgY = item.points.reduce((acc, p) => acc + p.y, 0) / item.points.length;

                  return (
                    <g
                      key={item.id}
                      className="cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedTakeoffId(item.id);
                      }}
                    >
                      <polygon
                        points={pointsStr}
                        fill={item.color}
                        fillOpacity={isSelected ? 0.35 : 0.22}
                        stroke={item.color}
                        strokeWidth={isSelected ? 3 : 2}
                        strokeDasharray={isSelected ? '6,3' : 'none'}
                      />
                      {/* Measurement Tag */}
                      <g transform={`translate(${avgX}, ${avgY})`}>
                        <rect
                          x="-45"
                          y="-14"
                          width="90"
                          height="28"
                          rx="4"
                          fill="#0f172a"
                          stroke={item.color}
                          strokeWidth="1.5"
                        />
                        <text
                          x="0"
                          y="4"
                          fill="#ffffff"
                          fontSize="11"
                          fontWeight="700"
                          textAnchor="middle"
                          className="font-mono-numbers"
                        >
                          {formatNumber(item.measurementValue)} {item.unit}
                        </text>
                      </g>
                    </g>
                  );
                }

                if (item.toolType === 'linear') {
                  const pointsStr = item.points.map((p) => `${p.x},${p.y}`).join(' ');
                  const midIdx = Math.floor(item.points.length / 2);
                  const midPoint = item.points[midIdx] || item.points[0];

                  return (
                    <g
                      key={item.id}
                      className="cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedTakeoffId(item.id);
                      }}
                    >
                      <polyline
                        points={pointsStr}
                        fill="none"
                        stroke={item.color}
                        strokeWidth={isSelected ? 5 : 3.5}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      {/* Vertex circles */}
                      {item.points.map((p, idx) => (
                        <circle
                          key={idx}
                          cx={p.x}
                          cy={p.y}
                          r={isSelected ? 5 : 3.5}
                          fill={item.color}
                          stroke="#ffffff"
                          strokeWidth="1"
                        />
                      ))}
                      {/* Tag */}
                      <g transform={`translate(${midPoint.x}, ${midPoint.y - 14})`}>
                        <rect
                          x="-35"
                          y="-12"
                          width="70"
                          height="22"
                          rx="3"
                          fill="#0f172a"
                          stroke={item.color}
                          strokeWidth="1.2"
                        />
                        <text
                          x="0"
                          y="3"
                          fill="#ffffff"
                          fontSize="10"
                          fontWeight="700"
                          textAnchor="middle"
                          className="font-mono-numbers"
                        >
                          {formatNumber(item.measurementValue, 1)} {item.unit}
                        </text>
                      </g>
                    </g>
                  );
                }

                if (item.toolType === 'count') {
                  const pt = item.points[0];
                  if (!pt) return null;

                  return (
                    <g
                      key={item.id}
                      transform={`translate(${pt.x}, ${pt.y})`}
                      className="cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedTakeoffId(item.id);
                      }}
                    >
                      <circle
                        cx="0"
                        cy="0"
                        r={isSelected ? 14 : 11}
                        fill={item.color}
                        fillOpacity="0.8"
                        stroke="#ffffff"
                        strokeWidth="2"
                      />
                      <text
                        x="0"
                        y="4"
                        fill="#ffffff"
                        fontSize="10"
                        fontWeight="800"
                        textAnchor="middle"
                      >
                        ✓
                      </text>
                    </g>
                  );
                }

                return null;
              })}

              {/* RENDER CURRENT IN-PROGRESS DRAWING */}
              {currentPoints.length > 0 && (
                <g className="in-progress-drawing pointer-events-none">
                  {/* Lines between existing points */}
                  {activeTool === 'area' && currentPoints.length >= 2 && (
                    <polygon
                      points={currentPoints.map((p) => `${p.x},${p.y}`).join(' ')}
                      fill={activeColor}
                      fillOpacity="0.15"
                      stroke={activeColor}
                      strokeWidth="2"
                      strokeDasharray="4,2"
                    />
                  )}
                  {activeTool === 'linear' && currentPoints.length >= 2 && (
                    <polyline
                      points={currentPoints.map((p) => `${p.x},${p.y}`).join(' ')}
                      fill="none"
                      stroke={activeColor}
                      strokeWidth="3"
                      strokeDasharray="4,2"
                    />
                  )}

                  {/* Rubber band line to hover point */}
                  {hoverPoint && (
                    <line
                      x1={currentPoints[currentPoints.length - 1].x}
                      y1={currentPoints[currentPoints.length - 1].y}
                      x2={hoverPoint.x}
                      y2={hoverPoint.y}
                      stroke={activeColor}
                      strokeWidth="1.5"
                      strokeDasharray="3,3"
                    />
                  )}

                  {/* Calibration line */}
                  {activeTool === 'calibrate' && currentPoints.length === 1 && hoverPoint && (
                    <line
                      x1={currentPoints[0].x}
                      y1={currentPoints[0].y}
                      x2={hoverPoint.x}
                      y2={hoverPoint.y}
                      stroke="#f43f5e"
                      strokeWidth="2.5"
                    />
                  )}

                  {/* Vertex nodes */}
                  {currentPoints.map((pt, idx) => (
                    <circle
                      key={idx}
                      cx={pt.x}
                      cy={pt.y}
                      r="4.5"
                      fill="#ffffff"
                      stroke={activeColor}
                      strokeWidth="2"
                    />
                  ))}
                </g>
              )}
            </g>
          </svg>
        </div>

        {/* Right Takeoff Ledger Drawer */}
        <div className="w-84 border-l border-neutral-800 bg-neutral-900 flex flex-col h-full">
          <div className="p-3 border-b border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-neutral-200">Sheet Takeoff Ledger</span>
              <span className="text-xs px-1.5 py-0.2 bg-neutral-800 text-neutral-400 rounded-full font-mono-numbers">
                {sheetTakeoffs.length} items
              </span>
            </div>
          </div>

          {/* List of Takeoff Items */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {sheetTakeoffs.length === 0 ? (
              <div className="py-12 text-center text-xs text-neutral-500">
                <p>No takeoffs measured on this sheet yet.</p>
                <p className="mt-1 text-neutral-400">
                  Select Area, Linear, or Count tool to start measuring.
                </p>
              </div>
            ) : (
              sheetTakeoffs.map((item) => {
                const isSelected = item.id === selectedTakeoffId;
                const isLinked = !!item.linkedEstimateItemId;

                return (
                  <div
                    key={item.id}
                    onClick={() => setSelectedTakeoffId(item.id)}
                    className={`p-2.5 rounded-lg border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-neutral-800 border-amber-500/80 shadow-md'
                        : 'bg-neutral-900/80 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="font-semibold text-neutral-200 truncate max-w-44">
                          {item.name}
                        </span>
                      </div>
                      <span className="font-bold text-neutral-100 font-mono-numbers shrink-0">
                        {formatNumber(item.measurementValue, item.unit === 'LF' ? 1 : 0)} {item.unit}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-neutral-400 pt-1.5 border-t border-neutral-800/80">
                      <div className="flex items-center gap-1.5">
                        <span className="text-neutral-500">Div {item.divisionCode}</span>
                        {item.toolType === 'area' && item.depthInches && (
                          <>
                            <span>·</span>
                            <span className="text-neutral-400">
                              {(
                                ((item.measurementValue * (item.depthInches / 12)) / 27).toFixed(1)
                              )}{' '}
                              CY
                            </span>
                          </>
                        )}
                        {item.toolType === 'linear' && item.heightFeet && (
                          <>
                            <span>·</span>
                            <span className="text-neutral-400">
                              {Math.round(item.measurementValue * item.heightFeet)} SF Wall
                            </span>
                          </>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        {isLinked ? (
                          <span
                            title="Linked to Master Estimate"
                            className="flex items-center gap-1 text-emerald-400 text-xs font-medium"
                          >
                            <Check className="w-3 h-3" />
                            <span>Linked</span>
                          </span>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setLinkingTakeoff(item);
                            }}
                            className="px-2 py-0.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 rounded border border-amber-500/30 flex items-center gap-1"
                          >
                            <LinkIcon className="w-3 h-3" />
                            <span>Link</span>
                          </button>
                        )}

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteTakeoff(item.id);
                          }}
                          className="p-1 text-neutral-500 hover:text-rose-400"
                          title="Delete takeoff"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Selected Takeoff Inspector */}
          {selectedTakeoff && (
            <div className="p-3 border-t border-neutral-800 bg-neutral-950/70">
              <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block mb-2">
                Edit Selected Takeoff
              </span>
              <div className="space-y-2">
                <div>
                  <label className="text-xs text-neutral-500 block">Name</label>
                  <input
                    type="text"
                    value={selectedTakeoff.name}
                    onChange={(e) =>
                      onUpdateTakeoff({ ...selectedTakeoff, name: e.target.value })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-xs text-neutral-200 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs text-neutral-500 block">CSI Div</label>
                    <input
                      type="text"
                      value={selectedTakeoff.divisionCode}
                      onChange={(e) =>
                        onUpdateTakeoff({ ...selectedTakeoff, divisionCode: e.target.value })
                      }
                      className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-xs text-neutral-200 font-mono-numbers"
                    />
                  </div>

                  {selectedTakeoff.toolType === 'area' && (
                    <div>
                      <label className="text-xs text-neutral-500 block">Slab Depth (in)</label>
                      <input
                        type="number"
                        value={selectedTakeoff.depthInches || 4}
                        onChange={(e) =>
                          onUpdateTakeoff({
                            ...selectedTakeoff,
                            depthInches: parseFloat(e.target.value) || 4,
                          })
                        }
                        className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-xs text-neutral-200 font-mono-numbers"
                      />
                    </div>
                  )}

                  {selectedTakeoff.toolType === 'linear' && (
                    <div>
                      <label className="text-xs text-neutral-500 block">Wall Ht (ft)</label>
                      <input
                        type="number"
                        value={selectedTakeoff.heightFeet || 12}
                        onChange={(e) =>
                          onUpdateTakeoff({
                            ...selectedTakeoff,
                            heightFeet: parseFloat(e.target.value) || 12,
                          })
                        }
                        className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-xs text-neutral-200 font-mono-numbers"
                      />
                    </div>
                  )}
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => {
                      onCreateEstimateFromTakeoff(selectedTakeoff, `${selectedTakeoff.divisionCode}-AUTO`);
                    }}
                    className="w-full py-1.5 px-3 bg-amber-600 hover:bg-amber-500 text-white font-medium rounded text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Create Estimate Line Item</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Calibration Modal */}
      {isCalibrateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-5 max-w-sm w-full shadow-2xl">
            <div className="flex items-center gap-2 mb-3">
              <Compass className="w-5 h-5 text-rose-500" />
              <h3 className="font-bold text-neutral-100 text-sm">Calibrate Sheet Scale</h3>
            </div>
            <p className="text-xs text-neutral-400 mb-4">
              Enter the real-world dimension in feet represented by the two clicked points (measured{' '}
              <strong className="text-neutral-200 font-mono-numbers">
                {Math.round(calibrationPixelDistance)} px
              </strong>
              ).
            </p>

            <div className="mb-4">
              <label className="text-xs text-neutral-300 font-medium block mb-1">
                Real Distance in Feet (e.g. 20 for 20'-0")
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.5"
                  value={realDistanceFeet}
                  onChange={(e) => setRealDistanceFeet(e.target.value)}
                  className="flex-1 bg-neutral-800 border border-neutral-700 rounded px-3 py-1.5 text-sm font-mono-numbers text-white focus:outline-none focus:border-amber-500"
                />
                <span className="text-xs text-neutral-400 font-semibold">FT</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setIsCalibrateModalOpen(false)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded"
              >
                Cancel
              </button>
              <button
                onClick={applyCalibration}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs rounded transition-colors"
              >
                Apply Calibration
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Link to Estimate Item Modal */}
      {linkingTakeoff && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-5 max-w-md w-full shadow-2xl">
            <div className="flex items-center gap-2 mb-3">
              <LinkIcon className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-neutral-100 text-sm">
                Link Takeoff to Estimate Line Item
              </h3>
            </div>
            <p className="text-xs text-neutral-400 mb-3">
              Select an existing line item in the Master Estimate to synchronize with this takeoff
              quantity:{' '}
              <strong className="text-amber-400 font-mono-numbers">
                {formatNumber(linkingTakeoff.measurementValue)} {linkingTakeoff.unit}
              </strong>
            </p>

            <div className="max-h-60 overflow-y-auto space-y-1.5 mb-4">
              {estimateItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedEstimateId(item.id)}
                  className={`p-2 rounded border text-xs cursor-pointer transition-colors ${
                    selectedEstimateId === item.id
                      ? 'bg-amber-500/20 border-amber-500 text-white font-medium'
                      : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:border-neutral-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono-numbers text-neutral-400">{item.itemCode}</span>
                    <span className="font-mono-numbers">
                      {formatNumber(item.quantity)} {item.unit}
                    </span>
                  </div>
                  <p className="text-xs truncate text-neutral-200 mt-0.5">{item.description}</p>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setLinkingTakeoff(null)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded"
              >
                Cancel
              </button>
              <button
                disabled={!selectedEstimateId}
                onClick={() => {
                  onLinkTakeoffToEstimate(linkingTakeoff, selectedEstimateId);
                  setLinkingTakeoff(null);
                }}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-medium text-xs rounded transition-colors"
              >
                Confirm Link
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
