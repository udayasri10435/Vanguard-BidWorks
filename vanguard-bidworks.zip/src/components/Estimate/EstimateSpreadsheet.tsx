import React, { useState } from 'react';
import { EstimateLineItem, Project, CostDatabaseItem } from '../../types';
import {
  formatCurrency,
  formatNumber,
  formatCurrencyCents,
} from '../../utils/calculations';
import {
  Search,
  Plus,
  Trash2,
  Copy,
  Download,
  Database,
  Unlink,
  Layers,
  Sparkles,
  ArrowUpDown,
  Filter,
} from 'lucide-react';

interface EstimateSpreadsheetProps {
  items: EstimateLineItem[];
  project: Project;
  onUpdateItem: (item: EstimateLineItem) => void;
  onAddItem: (item: EstimateLineItem) => void;
  onDeleteItem: (id: string) => void;
  onOpenCostDbModal: () => void;
  onNavigateToTakeoffs: () => void;
}

export const EstimateSpreadsheet: React.FC<EstimateSpreadsheetProps> = ({
  items,
  project,
  onUpdateItem,
  onAddItem,
  onDeleteItem,
  onOpenCostDbModal,
  onNavigateToTakeoffs,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedDivision, setSelectedDivision] = useState<string>('all');

  // Filter items
  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.itemCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.divisionName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDiv =
      selectedDivision === 'all' || item.divisionCode === selectedDivision;
    return matchesSearch && matchesDiv;
  });

  // Unique divisions present
  const availableDivisions = Array.from(
    new Set(items.map((i) => `${i.divisionCode}|${i.divisionName}`))
  ).map((str) => {
    const [code, name] = str.split('|');
    return { code, name };
  }).sort((a, b) => a.code.localeCompare(b.code));

  // Group items by Division
  const itemsByDivision: { [divCode: string]: EstimateLineItem[] } = {};
  filteredItems.forEach((item) => {
    if (!itemsByDivision[item.divisionCode]) {
      itemsByDivision[item.divisionCode] = [];
    }
    itemsByDivision[item.divisionCode].push(item);
  });

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Division Code',
      'Division Name',
      'Item Code',
      'Description',
      'Quantity',
      'Unit',
      'Labor Rate ($)',
      'Material Rate ($)',
      'Equipment Rate ($)',
      'Subcontract Rate ($)',
      'Total Unit Rate ($)',
      'Line Total ($)',
      'Takeoff Source',
    ];

    const rows = items.map((i) => {
      const unitTotal =
        (Number(i.laborRate) || 0) +
        (Number(i.materialRate) || 0) +
        (Number(i.equipmentRate) || 0) +
        (Number(i.subcontractorRate) || 0);
      const lineTotal = (Number(i.quantity) || 0) * unitTotal;
      return [
        `"${i.divisionCode}"`,
        `"${i.divisionName}"`,
        `"${i.itemCode}"`,
        `"${i.description.replace(/"/g, '""')}"`,
        i.quantity,
        `"${i.unit}"`,
        i.laborRate,
        i.materialRate,
        i.equipmentRate,
        i.subcontractorRate,
        unitTotal,
        lineTotal,
        `"${i.takeoffLabel || ''}"`,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${project.number}_Estimate_Schedule_of_Values.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddNewBlankLine = () => {
    const newItem: EstimateLineItem = {
      id: 'est-' + Date.now(),
      projectId: project.id,
      divisionCode: selectedDivision !== 'all' ? selectedDivision : '09',
      divisionName: selectedDivision !== 'all' ? (items.find(i => i.divisionCode === selectedDivision)?.divisionName || 'Finishes') : 'Finishes',
      itemCode: '09-NEW',
      description: 'New estimate item description',
      quantity: 1,
      unit: 'LS',
      laborRate: 0,
      materialRate: 0,
      equipmentRate: 0,
      subcontractorRate: 0,
    };
    onAddItem(newItem);
  };

  const handleDuplicateItem = (item: EstimateLineItem) => {
    const dup: EstimateLineItem = {
      ...item,
      id: 'est-' + Date.now(),
      description: `${item.description} (Copy)`,
      takeoffId: undefined,
      takeoffLabel: undefined,
    };
    onAddItem(dup);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-950 overflow-hidden">
      {/* Spreadsheet Control Bar */}
      <div className="p-3 bg-neutral-900 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-lg">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search CSI items, codes, descriptions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-neutral-800/80 border border-neutral-700/80 rounded-md pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-neutral-500" />
            <select
              value={selectedDivision}
              onChange={(e) => setSelectedDivision(e.target.value)}
              className="bg-neutral-800 border border-neutral-700 text-xs text-neutral-300 rounded px-2.5 py-1.5 focus:outline-none focus:border-amber-500"
            >
              <option value="all">All Divisions ({items.length})</option>
              {availableDivisions.map((div) => (
                <option key={div.code} value={div.code}>
                  Div {div.code} - {div.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenCostDbModal}
            className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded border border-neutral-700 flex items-center gap-1.5 transition-colors"
          >
            <Database className="w-3.5 h-3.5 text-amber-400" />
            <span>Add from Cost Catalog</span>
          </button>

          <button
            onClick={handleAddNewBlankLine}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Line Item</span>
          </button>

          <button
            onClick={handleExportCSV}
            title="Export Estimate to CSV"
            className="p-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded border border-neutral-700"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Spreadsheet Table Viewport */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="sticky top-0 z-20 bg-neutral-900 border-b border-neutral-800 text-neutral-400 font-semibold uppercase tracking-wider text-[11px]">
              <th className="py-2.5 px-3 w-28">Item Code</th>
              <th className="py-2.5 px-3 min-w-64">Description</th>
              <th className="py-2.5 px-3 w-44">Takeoff Source</th>
              <th className="py-2.5 px-3 w-24 text-right">Quantity</th>
              <th className="py-2.5 px-3 w-16 text-center">Unit</th>
              <th className="py-2.5 px-3 w-24 text-right">Labor ($)</th>
              <th className="py-2.5 px-3 w-24 text-right">Material ($)</th>
              <th className="py-2.5 px-3 w-24 text-right">Equip ($)</th>
              <th className="py-2.5 px-3 w-28 text-right">Subcontract ($)</th>
              <th className="py-2.5 px-3 w-24 text-right">Unit Total</th>
              <th className="py-2.5 px-3 w-32 text-right">Line Total</th>
              <th className="py-2.5 px-3 w-16 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-900">
            {Object.keys(itemsByDivision).length === 0 ? (
              <tr>
                <td colSpan={12} className="py-16 text-center text-neutral-500">
                  <Database className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                  <p className="text-sm font-medium">No estimate items match your filter.</p>
                  <p className="text-xs text-neutral-400 mt-1">
                    Add items from the Cost Catalog or create a new blank line.
                  </p>
                </td>
              </tr>
            ) : (
              Object.keys(itemsByDivision).map((divCode) => {
                const divItems = itemsByDivision[divCode];
                const divName = divItems[0]?.divisionName || '';

                // Subtotal for division
                const divSubtotal = divItems.reduce((acc, item) => {
                  const unitTotal =
                    (Number(item.laborRate) || 0) +
                    (Number(item.materialRate) || 0) +
                    (Number(item.equipmentRate) || 0) +
                    (Number(item.subcontractorRate) || 0);
                  return acc + (Number(item.quantity) || 0) * unitTotal;
                }, 0);

                return (
                  <React.Fragment key={divCode}>
                    {/* CSI Division Header Row */}
                    <tr className="bg-neutral-900/90 font-bold border-y border-neutral-800 text-neutral-200">
                      <td colSpan={10} className="py-2 px-3 text-xs tracking-wide">
                        <span className="text-amber-400 font-mono-numbers mr-2">
                          Division {divCode}
                        </span>
                        <span>{divName}</span>
                        <span className="text-neutral-500 font-normal ml-2">
                          ({divItems.length} {divItems.length === 1 ? 'item' : 'items'})
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-mono-numbers text-amber-300 font-bold">
                        {formatCurrency(divSubtotal)}
                      </td>
                      <td />
                    </tr>

                    {/* Division Items */}
                    {divItems.map((item) => {
                      const unitTotal =
                        (Number(item.laborRate) || 0) +
                        (Number(item.materialRate) || 0) +
                        (Number(item.equipmentRate) || 0) +
                        (Number(item.subcontractorRate) || 0);
                      const lineTotal = (Number(item.quantity) || 0) * unitTotal;
                      const hasTakeoff = !!item.takeoffId;

                      return (
                        <tr
                          key={item.id}
                          className="hover:bg-neutral-900/40 transition-colors group"
                        >
                          {/* Item Code */}
                          <td className="py-2 px-3 font-mono-numbers font-medium text-neutral-300">
                            <input
                              type="text"
                              value={item.itemCode}
                              onChange={(e) =>
                                onUpdateItem({ ...item, itemCode: e.target.value })
                              }
                              className="w-full bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none text-neutral-300 font-mono-numbers"
                            />
                          </td>

                          {/* Description */}
                          <td className="py-2 px-3 text-neutral-200">
                            <input
                              type="text"
                              value={item.description}
                              onChange={(e) =>
                                onUpdateItem({ ...item, description: e.target.value })
                              }
                              className="w-full bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1.5 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none text-neutral-100"
                            />
                          </td>

                          {/* Takeoff Source */}
                          <td className="py-2 px-3">
                            {hasTakeoff ? (
                              <div className="flex items-center gap-1.5 group/tag">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-sky-950 text-sky-400 border border-sky-800/80 rounded text-[10px] font-medium truncate max-w-36">
                                  <Layers className="w-2.5 h-2.5 shrink-0" />
                                  <span className="truncate">{item.takeoffLabel}</span>
                                </span>
                                <button
                                  onClick={() =>
                                    onUpdateItem({
                                      ...item,
                                      takeoffId: undefined,
                                      takeoffLabel: undefined,
                                    })
                                  }
                                  title="Unlink from takeoff"
                                  className="text-neutral-500 hover:text-rose-400 opacity-0 group-hover/tag:opacity-100"
                                >
                                  <Unlink className="w-3 h-3" />
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={onNavigateToTakeoffs}
                                className="text-neutral-500 hover:text-neutral-300 text-[11px] underline flex items-center gap-1"
                              >
                                <span>+ Link Takeoff</span>
                              </button>
                            )}
                          </td>

                          {/* Quantity */}
                          <td className="py-2 px-3 text-right">
                            <input
                              type="number"
                              value={item.quantity}
                              onChange={(e) =>
                                onUpdateItem({
                                  ...item,
                                  quantity: parseFloat(e.target.value) || 0,
                                })
                              }
                              className="w-20 text-right bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none font-mono-numbers text-neutral-100 font-bold"
                            />
                          </td>

                          {/* Unit */}
                          <td className="py-2 px-3 text-center font-mono-numbers text-neutral-400 text-xs">
                            <input
                              type="text"
                              value={item.unit}
                              onChange={(e) =>
                                onUpdateItem({ ...item, unit: e.target.value.toUpperCase() })
                              }
                              className="w-12 text-center bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none font-mono-numbers text-neutral-400"
                            />
                          </td>

                          {/* Labor Rate */}
                          <td className="py-2 px-3 text-right">
                            <input
                              type="number"
                              step="0.01"
                              value={item.laborRate}
                              onChange={(e) =>
                                onUpdateItem({
                                  ...item,
                                  laborRate: parseFloat(e.target.value) || 0,
                                })
                              }
                              className="w-20 text-right bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none font-mono-numbers text-neutral-300"
                            />
                          </td>

                          {/* Material Rate */}
                          <td className="py-2 px-3 text-right">
                            <input
                              type="number"
                              step="0.01"
                              value={item.materialRate}
                              onChange={(e) =>
                                onUpdateItem({
                                  ...item,
                                  materialRate: parseFloat(e.target.value) || 0,
                                })
                              }
                              className="w-20 text-right bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none font-mono-numbers text-neutral-300"
                            />
                          </td>

                          {/* Equipment Rate */}
                          <td className="py-2 px-3 text-right">
                            <input
                              type="number"
                              step="0.01"
                              value={item.equipmentRate}
                              onChange={(e) =>
                                onUpdateItem({
                                  ...item,
                                  equipmentRate: parseFloat(e.target.value) || 0,
                                })
                              }
                              className="w-20 text-right bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none font-mono-numbers text-neutral-300"
                            />
                          </td>

                          {/* Subcontractor Rate */}
                          <td className="py-2 px-3 text-right">
                            <input
                              type="number"
                              step="1"
                              value={item.subcontractorRate}
                              onChange={(e) =>
                                onUpdateItem({
                                  ...item,
                                  subcontractorRate: parseFloat(e.target.value) || 0,
                                })
                              }
                              className="w-24 text-right bg-transparent hover:bg-neutral-800 focus:bg-neutral-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500 focus:outline-none font-mono-numbers text-neutral-300"
                            />
                          </td>

                          {/* Total Unit Cost */}
                          <td className="py-2 px-3 text-right font-mono-numbers text-neutral-400 font-medium">
                            {formatCurrencyCents(unitTotal)}
                          </td>

                          {/* Line Total */}
                          <td className="py-2 px-3 text-right font-mono-numbers font-bold text-neutral-100">
                            {formatCurrency(lineTotal)}
                          </td>

                          {/* Row Actions */}
                          <td className="py-2 px-3 text-center">
                            <div className="flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button
                                onClick={() => handleDuplicateItem(item)}
                                title="Duplicate Line"
                                className="p-1 text-neutral-400 hover:text-white"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => onDeleteItem(item.id)}
                                title="Delete Line"
                                className="p-1 text-neutral-400 hover:text-rose-400"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
