import React from 'react';
import { EstimateFinancials, Project } from '../../types';
import { formatCurrency, formatPercent, formatCurrencyCents } from '../../utils/calculations';
import { MarkupSettings } from '../../utils/storage';
import { TrendingUp, ShieldAlert, DollarSign, PieChart, Sliders } from 'lucide-react';

interface FinancialMarkupSidebarProps {
  financials: EstimateFinancials;
  markupSettings: MarkupSettings;
  onUpdateMarkupSettings: (settings: MarkupSettings) => void;
  project: Project;
}

export const FinancialMarkupSidebar: React.FC<FinancialMarkupSidebarProps> = ({
  financials,
  markupSettings,
  onUpdateMarkupSettings,
  project,
}) => {
  const updateSetting = (key: keyof MarkupSettings, value: number) => {
    onUpdateMarkupSettings({
      ...markupSettings,
      [key]: value,
    });
  };

  // Model Win Probability based on margin:
  // Typical commercial GC curve: ~10% margin is sweet spot (52% win rate)
  // Below 8% margin increases win rate to 70%+; Above 15% drops below 25%
  const margin = markupSettings.targetProfitMarginPercent;
  let estimatedWinProb = Math.max(5, Math.min(88, Math.round(92 - margin * 4.2)));

  return (
    <div className="w-80 border-l border-neutral-800 bg-neutral-900/90 flex flex-col h-full overflow-y-auto">
      {/* Header */}
      <div className="p-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-900">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-amber-500" />
          <h3 className="text-xs font-bold text-neutral-100 uppercase tracking-wider">
            Bid Buildup & Markup
          </h3>
        </div>
        <span className="text-xs font-mono-numbers text-neutral-400">
          {formatPercent(financials.grossMarginPercent)} GM
        </span>
      </div>

      <div className="p-4 space-y-5 flex-1">
        {/* Total Gross Bid Callout */}
        <div className="p-3.5 bg-neutral-950 rounded-xl border border-neutral-800 shadow-inner">
          <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block">
            Total Gross Bid Proposal
          </span>
          <div className="text-2xl font-black text-amber-400 font-mono-numbers mt-1">
            {formatCurrency(financials.grossBidTotal)}
          </div>
          <div className="mt-2 pt-2 border-t border-neutral-800/80 flex items-center justify-between text-xs">
            <span className="text-neutral-400">Price / SF:</span>
            <span className="font-bold text-neutral-200 font-mono-numbers">
              {formatCurrencyCents(financials.costPerSF)} / SF
            </span>
          </div>
          <div className="mt-1 flex items-center justify-between text-xs">
            <span className="text-neutral-400">Gross Margin $:</span>
            <span className="font-bold text-emerald-400 font-mono-numbers">
              {formatCurrency(financials.grossProfitTotal)} ({formatPercent(financials.grossMarginPercent)})
            </span>
          </div>
        </div>

        {/* Win Probability Sensitivity Index */}
        <div className="p-3 bg-neutral-800/60 rounded-lg border border-neutral-700/60 text-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="font-semibold text-neutral-300 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-sky-400" />
              Win Probability Model
            </span>
            <span
              className={`font-bold font-mono-numbers ${
                estimatedWinProb > 50
                  ? 'text-emerald-400'
                  : estimatedWinProb > 30
                  ? 'text-amber-400'
                  : 'text-rose-400'
              }`}
            >
              ~{estimatedWinProb}%
            </span>
          </div>
          <div className="w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                estimatedWinProb > 50
                  ? 'bg-emerald-500'
                  : estimatedWinProb > 30
                  ? 'bg-amber-500'
                  : 'bg-rose-500'
              }`}
              style={{ width: `${estimatedWinProb}%` }}
            />
          </div>
          <p className="mt-2 text-neutral-400 text-xs leading-relaxed">
            Based on {project.sector} historical bid spreads. A{' '}
            <strong className="text-neutral-200">{margin}%</strong> profit margin offers balanced
            competitiveness.
          </p>
        </div>

        {/* Direct Costs Breakdown */}
        <div>
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block mb-2">
            1. Direct Field Costs
          </span>
          <div className="space-y-1.5 text-xs bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800">
            <div className="flex justify-between">
              <span className="text-neutral-400">Direct Labor:</span>
              <span className="font-mono-numbers text-neutral-200 font-medium">
                {formatCurrency(financials.directLaborTotal)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Materials:</span>
              <span className="font-mono-numbers text-neutral-200 font-medium">
                {formatCurrency(financials.directMaterialTotal)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Equipment Rental:</span>
              <span className="font-mono-numbers text-neutral-200 font-medium">
                {formatCurrency(financials.directEquipmentTotal)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Subcontractors:</span>
              <span className="font-mono-numbers text-neutral-200 font-medium">
                {formatCurrency(financials.directSubcontractTotal)}
              </span>
            </div>
            <div className="pt-2 border-t border-neutral-800 flex justify-between font-bold text-neutral-100">
              <span>Direct Cost Subtotal:</span>
              <span className="font-mono-numbers text-amber-300">
                {formatCurrency(financials.directCostTotal)}
              </span>
            </div>
          </div>
        </div>

        {/* Markups and Overhead */}
        <div className="space-y-4">
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block">
            2. Indirects, Overhead & Profit
          </span>

          {/* General Conditions */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-neutral-300">General Conditions (Super/Site)</span>
              <span className="font-mono-numbers font-bold text-neutral-200">
                {markupSettings.generalConditionsPercent}% (
                {formatCurrency(financials.generalConditionsAmount)})
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="20"
              step="0.5"
              value={markupSettings.generalConditionsPercent}
              onChange={(e) => updateSetting('generalConditionsPercent', parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
            />
          </div>

          {/* Contingency */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-neutral-300">Unforeseen Contingency</span>
              <span className="font-mono-numbers font-bold text-neutral-200">
                {markupSettings.contingencyPercent}% ({formatCurrency(financials.contingencyAmount)}
                )
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="15"
              step="0.5"
              value={markupSettings.contingencyPercent}
              onChange={(e) => updateSetting('contingencyPercent', parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
            />
          </div>

          {/* Overhead */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-neutral-300">Contractor Office Overhead</span>
              <span className="font-mono-numbers font-bold text-neutral-200">
                {markupSettings.overheadPercent}% ({formatCurrency(financials.overheadAmount)})
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="20"
              step="0.5"
              value={markupSettings.overheadPercent}
              onChange={(e) => updateSetting('overheadPercent', parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
            />
          </div>

          {/* Target Profit Margin */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-neutral-200 font-semibold">Target Profit Margin</span>
              <span className="font-mono-numbers font-bold text-emerald-400">
                {markupSettings.targetProfitMarginPercent}% (
                {formatCurrency(financials.targetProfitMarginAmount)})
              </span>
            </div>
            <input
              type="range"
              min="2"
              max="25"
              step="0.5"
              value={markupSettings.targetProfitMarginPercent}
              onChange={(e) =>
                updateSetting('targetProfitMarginPercent', parseFloat(e.target.value))
              }
              className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
            />
          </div>

          {/* Bond & Insurance */}
          <div className="pt-2 border-t border-neutral-800/80 space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-neutral-400">Performance & Payment Bond</span>
                <span className="font-mono-numbers text-neutral-300">
                  {markupSettings.bondRatePercent}% ({formatCurrency(financials.bondAmount)})
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="3"
                step="0.1"
                value={markupSettings.bondRatePercent}
                onChange={(e) => updateSetting('bondRatePercent', parseFloat(e.target.value))}
                className="w-full accent-neutral-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-neutral-400">Builders Risk & GL Insurance</span>
                <span className="font-mono-numbers text-neutral-300">
                  {markupSettings.insuranceRatePercent}% (
                  {formatCurrency(financials.insuranceAmount)})
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="4"
                step="0.1"
                value={markupSettings.insuranceRatePercent}
                onChange={(e) => updateSetting('insuranceRatePercent', parseFloat(e.target.value))}
                className="w-full accent-neutral-500 cursor-pointer h-1.5 bg-neutral-800 rounded-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
