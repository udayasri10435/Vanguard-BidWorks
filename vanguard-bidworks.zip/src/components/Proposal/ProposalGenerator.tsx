import React, { useState } from 'react';
import { Project, EstimateLineItem, EstimateFinancials } from '../../types';
import { formatCurrency, formatPercent, formatNumber } from '../../utils/calculations';
import { Printer, Download, FileCheck, CheckCircle2, Shield, Calendar, Building, Sparkles } from 'lucide-react';

interface ProposalGeneratorProps {
  project: Project;
  items: EstimateLineItem[];
  financials: EstimateFinancials;
  onOpenAiVE: () => void;
}

export const ProposalGenerator: React.FC<ProposalGeneratorProps> = ({
  project,
  items,
  financials,
  onOpenAiVE,
}) => {
  const [proposalNotes, setProposalNotes] = useState<string>(
    'Vanguard Builders is pleased to submit this formal lump-sum proposal for the complete commercial tenant buildout per project architectural bid set. All work complies with local building codes, ASHRAE standards, and manufacturer specifications.'
  );

  // Group by Division for the Schedule of Values
  const divisionTotals: { [code: string]: { name: string; total: number; count: number } } = {};
  items.forEach((item) => {
    const unitTotal =
      (Number(item.laborRate) || 0) +
      (Number(item.materialRate) || 0) +
      (Number(item.equipmentRate) || 0) +
      (Number(item.subcontractorRate) || 0);
    const lineTotal = (Number(item.quantity) || 0) * unitTotal;

    if (!divisionTotals[item.divisionCode]) {
      divisionTotals[item.divisionCode] = {
        name: item.divisionName,
        total: 0,
        count: 0,
      };
    }
    divisionTotals[item.divisionCode].total += lineTotal;
    divisionTotals[item.divisionCode].count += 1;
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-950 overflow-y-auto">
      {/* Top Banner Toolbar (Hidden during print) */}
      <div className="no-print p-3.5 bg-neutral-900 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3 sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <FileCheck className="w-5 h-5 text-amber-500" />
          <div>
            <h2 className="text-sm font-bold text-neutral-100">
              Client Bid Proposal & Schedule of Values
            </h2>
            <p className="text-xs text-neutral-400">
              Client-ready formal AIA-formatted construction proposal with legal qualifications
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAiVE}
            className="px-3 py-1.5 bg-sky-950/80 hover:bg-sky-900 text-sky-300 font-medium text-xs rounded border border-sky-700/80 flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>Generate Value Engineering Alternates</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded flex items-center gap-1.5 transition-colors shadow"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / Save as PDF</span>
          </button>
        </div>
      </div>

      {/* Proposal Document Canvas */}
      <div className="p-6 md:p-10 flex justify-center">
        <div className="w-full max-w-4xl bg-white text-neutral-900 rounded-xl shadow-2xl p-8 md:p-12 border border-neutral-200 print:shadow-none print:border-none print:p-0">
          {/* Header & Letterhead */}
          <div className="flex flex-col md:flex-row justify-between items-start border-b-2 border-neutral-900 pb-6 mb-8 gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 bg-amber-600 rounded-sm" />
                <h1 className="text-2xl font-black tracking-tight text-neutral-900 uppercase">
                  Vanguard BidWorks
                </h1>
              </div>
              <p className="text-xs font-semibold text-neutral-500 uppercase tracking-widest mt-1">
                Commercial General Contracting & Preconstruction
              </p>
              <div className="text-xs text-neutral-600 mt-2 space-y-0.5">
                <p>1200 Congress Avenue, Suite 800 · Austin, TX 78701</p>
                <p>Office: (512) 555-8900 · License #CGC-940211 · info@vanguardbidworks.com</p>
              </div>
            </div>

            <div className="text-left md:text-right text-xs">
              <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider block">
                Bid Submission Date
              </span>
              <p className="text-sm font-bold text-neutral-900 font-mono-numbers mt-0.5">
                September 28, 2026
              </p>
              <p className="text-xs text-neutral-500 mt-1">
                Project Reference: <strong className="text-neutral-900">{project.number}</strong>
              </p>
              <p className="text-xs text-neutral-500">
                Bid Validity: <strong className="text-neutral-900">30 Calendar Days</strong>
              </p>
            </div>
          </div>

          {/* Project & Client Recipient Block */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-neutral-50 p-4 rounded-lg border border-neutral-200 mb-8 text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider block mb-1">
                Submitted To (Client / Owner):
              </span>
              <p className="text-sm font-bold text-neutral-900">{project.client}</p>
              <p className="text-neutral-600 mt-0.5">Attn: Facilities & Capital Development</p>
              <p className="text-neutral-600">Location: {project.location}</p>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider block mb-1">
                Project Details:
              </span>
              <p className="text-sm font-bold text-neutral-900">{project.name}</p>
              <p className="text-neutral-600 mt-0.5">
                Architect of Record: <strong>{project.architect}</strong>
              </p>
              <p className="text-neutral-600">
                Gross Area: <strong>{formatNumber(project.squareFootage)} SF</strong> · Sector:{' '}
                <strong>{project.sector}</strong>
              </p>
            </div>
          </div>

          {/* Executive Summary */}
          <div className="mb-8">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 border-b border-neutral-300 pb-1.5 mb-2.5">
              1. Executive Scope & Proposal Statement
            </h3>
            <p className="text-xs text-neutral-700 leading-relaxed">{proposalNotes}</p>
          </div>

          {/* Schedule of Values (CSI MasterFormat Summary) */}
          <div className="mb-8">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 border-b border-neutral-300 pb-1.5 mb-2.5">
              2. Schedule of Values (By CSI MasterFormat Division)
            </h3>

            <table className="w-full border-collapse text-left text-xs mb-3">
              <thead>
                <tr className="bg-neutral-100 border-b border-neutral-300 text-neutral-700 font-semibold uppercase text-[10px]">
                  <th className="py-2 px-3 w-24">Division</th>
                  <th className="py-2 px-3">Description of Work</th>
                  <th className="py-2 px-3 text-center w-20">Line Items</th>
                  <th className="py-2 px-3 text-right w-36">Division Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {Object.keys(divisionTotals)
                  .sort()
                  .map((code) => {
                    const div = divisionTotals[code];
                    return (
                      <tr key={code} className="hover:bg-neutral-50/80">
                        <td className="py-2 px-3 font-mono-numbers font-bold text-neutral-800">
                          Div {code}
                        </td>
                        <td className="py-2 px-3 font-medium text-neutral-800">{div.name}</td>
                        <td className="py-2 px-3 text-center text-neutral-500 font-mono-numbers">
                          {div.count}
                        </td>
                        <td className="py-2 px-3 text-right font-mono-numbers font-bold text-neutral-900">
                          {formatCurrency(div.total)}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>

            {/* Buildup Totals Box */}
            <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-300 space-y-1.5 text-xs">
              <div className="flex justify-between text-neutral-600">
                <span>Direct Construction Work:</span>
                <span className="font-mono-numbers font-semibold text-neutral-900">
                  {formatCurrency(financials.directCostTotal)}
                </span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>General Conditions & Field Supervision:</span>
                <span className="font-mono-numbers font-semibold text-neutral-900">
                  {formatCurrency(financials.generalConditionsAmount)}
                </span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Contractor Contingency Allowance:</span>
                <span className="font-mono-numbers font-semibold text-neutral-900">
                  {formatCurrency(financials.contingencyAmount)}
                </span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Contractor Overhead & Project Management:</span>
                <span className="font-mono-numbers font-semibold text-neutral-900">
                  {formatCurrency(financials.overheadAmount)}
                </span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Performance & Payment Bond / General Liability:</span>
                <span className="font-mono-numbers font-semibold text-neutral-900">
                  {formatCurrency(financials.bondAmount + financials.insuranceAmount)}
                </span>
              </div>

              <div className="pt-2 border-t-2 border-neutral-900 flex justify-between items-baseline text-neutral-900">
                <div>
                  <span className="text-sm font-black uppercase tracking-wide">
                    Total Stipulated Gross Bid Price:
                  </span>
                  <span className="text-xs text-neutral-500 ml-2 font-mono-numbers">
                    ({formatCurrency(financials.costPerSF)} / SF)
                  </span>
                </div>
                <span className="text-xl font-black font-mono-numbers text-amber-700">
                  {formatCurrency(financials.grossBidTotal)}
                </span>
              </div>
            </div>
          </div>

          {/* Scope Inclusions and Exclusions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 text-xs">
            <div className="p-3.5 bg-neutral-50 rounded border border-neutral-200">
              <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5 text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Explicit Inclusions & Clarifications
              </h4>
              <ul className="list-disc list-inside space-y-1 text-neutral-600">
                <li>Full-time on-site project superintendent throughout construction.</li>
                <li>Standard daytime single-shift working hours (7:00 AM - 4:00 PM).</li>
                <li>Continuous jobsite dust control, HEPA floor protection, and waste disposal.</li>
                <li>One-year comprehensive contractor craftsmanship warranty from Substantial Completion.</li>
                <li>Final commercial post-construction turnover cleaning.</li>
              </ul>
            </div>

            <div className="p-3.5 bg-neutral-50 rounded border border-neutral-200">
              <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5 text-rose-700">
                <Shield className="w-3.5 h-3.5 text-rose-600" />
                Explicit Exclusions
              </h4>
              <ul className="list-disc list-inside space-y-1 text-neutral-600">
                <li>Remediation or abatement of unforeseen hazardous materials (asbestos, lead).</li>
                <li>Municipal water/sewer/power capacity development or utility tap impact fees.</li>
                <li>Owner-furnished furniture, fixtures, and IT server racks (FF&E).</li>
                <li>Architectural and structural engineering plan check permit fees (by Owner).</li>
                <li>Overtime premium labor unless explicitly requested in writing by Owner.</li>
              </ul>
            </div>
          </div>

          {/* Formal Acceptance & Signature Line */}
          <div className="pt-6 border-t-2 border-neutral-900 text-xs">
            <div className="grid grid-cols-2 gap-8 mb-4">
              <div>
                <span className="font-bold text-neutral-900 block mb-1">
                  Submitted by General Contractor:
                </span>
                <p className="text-neutral-600">Vanguard Builders & Preconstruction LLC</p>
                <div className="mt-8 border-b border-neutral-400 w-48" />
                <p className="text-[10px] text-neutral-500 mt-1">Authorized Estimating Officer Signature</p>
              </div>

              <div>
                <span className="font-bold text-neutral-900 block mb-1">
                  Accepted and Approved by Owner / Client:
                </span>
                <p className="text-neutral-600">{project.client}</p>
                <div className="mt-8 border-b border-neutral-400 w-48" />
                <p className="text-[10px] text-neutral-500 mt-1">Authorized Owner Representative Signature / Date</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
