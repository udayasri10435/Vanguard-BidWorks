import React, { useState } from 'react';
import { HistoricalBid, SectorType } from '../../types';
import {
  formatCurrency,
  formatPercent,
  formatNumber,
} from '../../utils/calculations';
import {
  TrendingUp,
  Award,
  AlertCircle,
  DollarSign,
  PieChart,
  BarChart3,
  Search,
  Filter,
  Plus,
  Building2,
  Calendar,
} from 'lucide-react';

interface WinLossDashboardProps {
  bids: HistoricalBid[];
  onAddHistoricalBid: (bid: HistoricalBid) => void;
}

export const WinLossDashboard: React.FC<WinLossDashboardProps> = ({
  bids,
  onAddHistoricalBid,
}) => {
  const [selectedSector, setSelectedSector] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);

  // New Bid Form State
  const [newProjectName, setNewProjectName] = useState<string>('');
  const [newSector, setNewSector] = useState<SectorType>('Commercial Office');
  const [newOurBid, setNewOurBid] = useState<number>(2000000);
  const [newWinBid, setNewWinBid] = useState<number>(1950000);
  const [newStatus, setNewStatus] = useState<'won' | 'lost'>('won');
  const [newMargin, setNewMargin] = useState<number>(13.5);
  const [newLossReason, setNewLossReason] = useState<string>('');

  // Filtered
  const filteredBids = bids.filter((b) => {
    const matchSec = selectedSector === 'all' || b.sector === selectedSector;
    const matchStat = selectedStatus === 'all' || b.status === selectedStatus;
    return matchSec && matchStat;
  });

  // KPI Calculations
  const totalBids = bids.length;
  const wonBids = bids.filter((b) => b.status === 'won');
  const lostBids = bids.filter((b) => b.status === 'lost');

  const winRate = totalBids > 0 ? (wonBids.length / totalBids) * 100 : 0;
  const totalWonRevenue = wonBids.reduce((acc, b) => acc + b.winningBidAmount, 0);

  // Average spread when lost: ((ourBid - winBid) / winBid) * 100
  const avgLostSpread =
    lostBids.length > 0
      ? lostBids.reduce((acc, b) => acc + b.spreadPercent, 0) / lostBids.length
      : 0;

  // Average "Money left on the table" when won: spread vs 2nd place
  const avgWonSpread =
    wonBids.length > 0
      ? Math.abs(wonBids.reduce((acc, b) => acc + b.spreadPercent, 0) / wonBids.length)
      : 0;

  const avgMargin =
    bids.length > 0
      ? bids.reduce((acc, b) => acc + b.plannedMarginPercent, 0) / bids.length
      : 0;

  // Breakdown by Sector
  const sectors: SectorType[] = [
    'Commercial Office',
    'Healthcare & Medical',
    'Industrial & Warehouse',
    'Retail & Restaurant',
    'Educational / Institutional',
    'Tenant Improvement',
  ];

  const sectorMetrics = sectors.map((sec) => {
    const secBids = bids.filter((b) => b.sector === sec);
    const secWon = secBids.filter((b) => b.status === 'won');
    const rate = secBids.length > 0 ? (secWon.length / secBids.length) * 100 : 0;
    return {
      sector: sec,
      total: secBids.length,
      won: secWon.length,
      winRate: Math.round(rate),
    };
  }).filter((s) => s.total > 0);

  const handleSaveNewBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName) return;

    const spread =
      newStatus === 'won'
        ? -1.5
        : ((newOurBid - newWinBid) / newWinBid) * 100;

    const bid: HistoricalBid = {
      id: 'hb-' + Date.now(),
      projectName: newProjectName,
      sector: newSector,
      squareFootage: 20000,
      ownerClient: 'Confidential Client',
      architect: 'Design Collaborative',
      bidDate: new Date().toISOString().split('T')[0],
      ourBidAmount: newOurBid,
      winningBidAmount: newStatus === 'won' ? newOurBid : newWinBid,
      spreadPercent: Math.round(spread * 100) / 100,
      plannedMarginPercent: newMargin,
      status: newStatus,
      lossReason: newStatus === 'lost' ? newLossReason : undefined,
    };

    onAddHistoricalBid(bid);
    setIsAddModalOpen(false);
    setNewProjectName('');
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-950 overflow-y-auto">
      {/* Top Banner */}
      <div className="p-3.5 bg-neutral-900 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <TrendingUp className="w-5 h-5 text-amber-500" />
          <div>
            <h2 className="text-sm font-bold text-neutral-100">
              Win / Loss & Bid Spread Analytics
            </h2>
            <p className="text-xs text-neutral-400">
              Contractor bidding intelligence, competitor spreads, and margin realization
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded flex items-center gap-1.5 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Record Past Bid Result</span>
        </button>
      </div>

      <div className="p-4 space-y-6">
        {/* KPI Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
          {/* Win Rate */}
          <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-xl">
            <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block">
              Overall Win Rate
            </span>
            <div className="text-2xl font-black text-emerald-400 font-mono-numbers mt-1">
              {formatPercent(winRate)}
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              {wonBids.length} won out of {totalBids} submitted bids
            </p>
          </div>

          {/* Won Revenue */}
          <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-xl">
            <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block">
              Total Won Backlog
            </span>
            <div className="text-2xl font-black text-amber-400 font-mono-numbers mt-1">
              {formatCurrency(totalWonRevenue)}
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Average award size {formatCurrency(wonBids.length > 0 ? totalWonRevenue / wonBids.length : 0)}
            </p>
          </div>

          {/* Average Loss Spread */}
          <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-xl">
            <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block">
              Avg Spread When Lost
            </span>
            <div className="text-2xl font-black text-rose-400 font-mono-numbers mt-1">
              +{formatPercent(avgLostSpread)}
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Over competitor low bidder price
            </p>
          </div>

          {/* Money Left on Table */}
          <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-xl">
            <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block">
              Money Left on Table
            </span>
            <div className="text-2xl font-black text-sky-400 font-mono-numbers mt-1">
              {formatPercent(avgWonSpread)}
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Average margin buffer vs 2nd place
            </p>
          </div>
        </div>

        {/* Visual Analytics Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Win Rate by Sector Bar Chart */}
          <div className="p-4 bg-neutral-900/90 border border-neutral-800 rounded-xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-amber-500" />
                Win Rate by Project Sector
              </h3>
              <span className="text-xs text-neutral-400">Target Benchmark: 40%+</span>
            </div>

            <div className="space-y-3 pt-1">
              {sectorMetrics.map((sm) => (
                <div key={sm.sector} className="space-y-1 text-xs">
                  <div className="flex justify-between text-neutral-300">
                    <span className="font-medium">{sm.sector}</span>
                    <span className="font-mono-numbers font-bold text-neutral-200">
                      {sm.winRate}% ({sm.won}/{sm.total})
                    </span>
                  </div>
                  <div className="w-full bg-neutral-950 rounded-full h-2 overflow-hidden border border-neutral-800">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        sm.winRate >= 50
                          ? 'bg-emerald-500'
                          : sm.winRate >= 30
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.max(sm.winRate, 5)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Loss Drivers & Risk Breakdown */}
          <div className="p-4 bg-neutral-900/90 border border-neutral-800 rounded-xl flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5 mb-3">
                <AlertCircle className="w-4 h-4 text-rose-400" />
                Primary Loss Driver Analysis
              </h3>
              <div className="space-y-2.5 text-xs">
                <div className="p-2.5 bg-neutral-950 rounded-lg border border-neutral-800 flex items-start gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold text-neutral-200 block">
                      Subcontractor Package Competitiveness (50%)
                    </span>
                    <p className="text-neutral-400 mt-0.5">
                      Competitors held lower proprietary concrete & MEP sub quotes through regional master agreements.
                    </p>
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-950 rounded-lg border border-neutral-800 flex items-start gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold text-neutral-200 block">
                      Self-Perform vs Subcontracted Framing (25%)
                    </span>
                    <p className="text-neutral-400 mt-0.5">
                      Winning GCs self-performed drywall framing, saving approx 4-6% on division 09 labor.
                    </p>
                  </div>
                </div>

                <div className="p-2.5 bg-neutral-950 rounded-lg border border-neutral-800 flex items-start gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-sky-500 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold text-neutral-200 block">
                      Overhead & Contingency Sizing (25%)
                    </span>
                    <p className="text-neutral-400 mt-0.5">
                      High contingency buffers on public work exceeded tight client threshold limits.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
              <span>Overall Average Planned Margin:</span>
              <span className="font-bold font-mono-numbers text-neutral-200">
                {formatPercent(avgMargin)}
              </span>
            </div>
          </div>
        </div>

        {/* Historical Bid Log Table */}
        <div className="border border-neutral-800 rounded-xl overflow-hidden bg-neutral-900 shadow-lg">
          <div className="p-3 bg-neutral-900 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider">
              Historical Bid Log & Competitor Results
            </h3>

            <div className="flex items-center gap-2">
              <select
                value={selectedSector}
                onChange={(e) => setSelectedSector(e.target.value)}
                className="bg-neutral-800 border border-neutral-700 text-xs text-neutral-300 rounded px-2.5 py-1"
              >
                <option value="all">All Sectors</option>
                {sectors.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>

              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-neutral-800 border border-neutral-700 text-xs text-neutral-300 rounded px-2.5 py-1"
              >
                <option value="all">All Outcomes</option>
                <option value="won">Won Only</option>
                <option value="lost">Lost Only</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="bg-neutral-950 text-neutral-400 font-semibold uppercase tracking-wider text-[11px] border-b border-neutral-800">
                  <th className="py-2.5 px-3">Project & Client</th>
                  <th className="py-2.5 px-3">Sector</th>
                  <th className="py-2.5 px-3">Bid Date</th>
                  <th className="py-2.5 px-3 text-right">Our Bid ($)</th>
                  <th className="py-2.5 px-3 text-right">Winning Bid ($)</th>
                  <th className="py-2.5 px-3 text-right">Spread (%)</th>
                  <th className="py-2.5 px-3 text-right">Margin (%)</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 min-w-56">Outcome Notes / Loss Driver</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-850">
                {filteredBids.map((b) => {
                  const isWon = b.status === 'won';
                  return (
                    <tr key={b.id} className="hover:bg-neutral-850/50 transition-colors">
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-neutral-200">{b.projectName}</div>
                        <div className="text-[11px] text-neutral-400">
                          {b.ownerClient} · Arch: {b.architect}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-neutral-400">{b.sector}</td>
                      <td className="py-2.5 px-3 font-mono-numbers text-neutral-400">{b.bidDate}</td>
                      <td className="py-2.5 px-3 text-right font-mono-numbers font-medium text-neutral-200">
                        {formatCurrency(b.ourBidAmount)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-300">
                        {formatCurrency(b.winningBidAmount)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono-numbers font-bold">
                        <span className={b.spreadPercent > 0 ? 'text-rose-400' : 'text-emerald-400'}>
                          {b.spreadPercent > 0 ? `+${b.spreadPercent}%` : `${b.spreadPercent}%`}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-300">
                        {formatPercent(b.plannedMarginPercent)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                            isWon
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-rose-950 text-rose-400 border border-rose-800'
                          }`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-neutral-400 text-[11px]">
                        {isWon ? (
                          <span className="text-emerald-400/90 font-medium">
                            Awarded contract · Successful interview & pricing
                          </span>
                        ) : (
                          <div>
                            <span className="text-neutral-300 font-medium">Winner: {b.competitorWinner || 'Competitor'}</span>
                            {b.lossReason && <div className="text-neutral-400 mt-0.5">{b.lossReason}</div>}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Record Past Bid Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-5 max-w-md w-full shadow-2xl">
            <h3 className="font-bold text-neutral-100 text-sm mb-3">
              Record Historical Bid Outcome
            </h3>

            <form onSubmit={handleSaveNewBid} className="space-y-3 text-xs">
              <div>
                <label className="text-neutral-400 block mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Austin Regional Hospital Tower"
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-400 block mb-1">Sector</label>
                  <select
                    value={newSector}
                    onChange={(e) => setNewSector(e.target.value as SectorType)}
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1.5 text-neutral-100"
                  >
                    {sectors.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Outcome</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as 'won' | 'lost')}
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1.5 text-neutral-100"
                  >
                    <option value="won">Won Contract</option>
                    <option value="lost">Lost to Competitor</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-400 block mb-1">Our Bid Amount ($)</label>
                  <input
                    type="number"
                    required
                    value={newOurBid}
                    onChange={(e) => setNewOurBid(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 font-mono-numbers text-neutral-100"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Winning Bid Amount ($)</label>
                  <input
                    type="number"
                    required
                    value={newWinBid}
                    onChange={(e) => setNewWinBid(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 font-mono-numbers text-neutral-100"
                  />
                </div>
              </div>

              {newStatus === 'lost' && (
                <div>
                  <label className="text-neutral-400 block mb-1">Loss Reason & Debrief</label>
                  <input
                    type="text"
                    placeholder="e.g. Competitor was 3% lower on MEP package"
                    value={newLossReason}
                    onChange={(e) => setNewLossReason(e.target.value)}
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                  />
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded transition-colors"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
