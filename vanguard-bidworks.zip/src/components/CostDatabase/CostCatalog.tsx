import React, { useState } from 'react';
import { CostDatabaseItem, RegionalModifier } from '../../types';
import { regionalModifiers } from '../../data/initialData';
import { formatCurrencyCents, formatNumber } from '../../utils/calculations';
import {
  Search,
  Plus,
  MapPin,
  Download,
  Upload,
  Check,
  PlusCircle,
  FolderOpen,
} from 'lucide-react';

interface CostCatalogProps {
  items: CostDatabaseItem[];
  onAddItem: (item: CostDatabaseItem) => void;
  onPushToEstimate: (item: CostDatabaseItem, quantity: number) => void;
  activeRegionKey: string;
  onChangeRegion: (regionKey: string) => void;
}

export const CostCatalog: React.FC<CostCatalogProps> = ({
  items,
  onAddItem,
  onPushToEstimate,
  activeRegionKey,
  onChangeRegion,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedDivision, setSelectedDivision] = useState<string>('all');
  const [isNewItemModalOpen, setIsNewItemModalOpen] = useState<boolean>(false);

  // Quick push to estimate state
  const [pushingItem, setPushingItem] = useState<CostDatabaseItem | null>(null);
  const [pushQuantity, setPushQuantity] = useState<number>(100);

  const activeRegion =
    regionalModifiers.find((r) => r.key === activeRegionKey) || regionalModifiers[0];

  // Available unique divisions
  const divisions = Array.from(
    new Set(items.map((i) => `${i.divisionCode}|${i.divisionName}`))
  ).map((str) => {
    const [code, name] = str.split('|');
    return { code, name };
  }).sort((a, b) => a.code.localeCompare(b.code));

  // Filter items
  const filtered = items.filter((item) => {
    const matchesSearch =
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.itemCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.divisionName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDiv = selectedDivision === 'all' || item.divisionCode === selectedDivision;
    return matchesSearch && matchesDiv;
  });

  // New Custom Item Form State
  const [newItemForm, setNewItemForm] = useState<Partial<CostDatabaseItem>>({
    divisionCode: '09',
    divisionName: 'Finishes',
    itemCode: '09-',
    description: '',
    unit: 'SF',
    laborRate: 5.5,
    crewOutputDaily: 1000,
    materialRate: 3.2,
    equipmentRate: 0.5,
    subcontractorRate: 0,
    notes: '',
  });

  const handleCreateCustomItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemForm.description || !newItemForm.itemCode) return;

    const item: CostDatabaseItem = {
      id: 'db-custom-' + Date.now(),
      divisionCode: newItemForm.divisionCode || '09',
      divisionName: newItemForm.divisionName || 'Finishes',
      itemCode: newItemForm.itemCode,
      description: newItemForm.description,
      unit: newItemForm.unit || 'SF',
      laborRate: Number(newItemForm.laborRate) || 0,
      crewOutputDaily: Number(newItemForm.crewOutputDaily) || 1,
      materialRate: Number(newItemForm.materialRate) || 0,
      equipmentRate: Number(newItemForm.equipmentRate) || 0,
      subcontractorRate: Number(newItemForm.subcontractorRate) || 0,
      notes: newItemForm.notes || 'Company Custom Cost Item',
      isCustom: true,
    };
    onAddItem(item);
    setIsNewItemModalOpen(false);
  };

  const handleExportCSV = () => {
    const headers = [
      'Division',
      'Division Name',
      'Item Code',
      'Description',
      'Unit',
      'Labor Rate ($)',
      'Crew Daily Output',
      'Material Rate ($)',
      'Equipment Rate ($)',
      'Subcontract Rate ($)',
      'Notes',
    ];

    const rows = items.map((i) => [
      `"${i.divisionCode}"`,
      `"${i.divisionName}"`,
      `"${i.itemCode}"`,
      `"${i.description.replace(/"/g, '""')}"`,
      `"${i.unit}"`,
      i.laborRate,
      i.crewOutputDaily,
      i.materialRate,
      i.equipmentRate,
      i.subcontractorRate,
      `"${(i.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const link = document.createElement('a');
    link.setAttribute('href', encodeURI(csvContent));
    link.setAttribute('download', `Vanguard_CSI_Cost_Database_${activeRegion.key}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-950 overflow-hidden">
      {/* Top Banner & Regional Factor Switcher */}
      <div className="p-3.5 bg-neutral-900 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <FolderOpen className="w-5 h-5 text-amber-500" />
          <div>
            <h2 className="text-sm font-bold text-neutral-100">
              MasterFormat CSI Cost Database
            </h2>
            <p className="text-xs text-neutral-400">
              Industry unit labor, material, and equipment productivity rates
            </p>
          </div>
        </div>

        {/* Regional Location Factor Multiplier */}
        <div className="flex items-center gap-2 bg-neutral-800/80 px-3 py-1.5 rounded-lg border border-neutral-700">
          <MapPin className="w-3.5 h-3.5 text-sky-400" />
          <span className="text-xs text-neutral-400 font-medium">Metro Region:</span>
          <select
            value={activeRegionKey}
            onChange={(e) => onChangeRegion(e.target.value)}
            className="bg-neutral-900 border border-neutral-700 rounded px-2 py-1 text-xs text-neutral-200 font-medium focus:outline-none focus:border-amber-500"
          >
            {regionalModifiers.map((r) => (
              <option key={r.key} value={r.key}>
                {r.name} ({r.laborFactor}x Labor)
              </option>
            ))}
          </select>
          <span className="text-xs font-mono-numbers text-sky-300 font-semibold ml-1">
            {activeRegion.laborFactor.toFixed(2)}x
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNewItemModalOpen(true)}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Custom Item</span>
          </button>

          <button
            onClick={handleExportCSV}
            title="Export Cost Database CSV"
            className="p-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded border border-neutral-700"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3 bg-neutral-900/60 border-b border-neutral-800 flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search database items, specs, materials..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-neutral-800/80 border border-neutral-700/80 rounded-md pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto py-1">
          <button
            onClick={() => setSelectedDivision('all')}
            className={`px-2.5 py-1 rounded text-xs whitespace-nowrap transition-colors ${
              selectedDivision === 'all'
                ? 'bg-neutral-800 text-white font-semibold border border-neutral-700'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            All Divisions ({items.length})
          </button>
          {divisions.map((div) => (
            <button
              key={div.code}
              onClick={() => setSelectedDivision(div.code)}
              className={`px-2.5 py-1 rounded text-xs whitespace-nowrap transition-colors ${
                selectedDivision === div.code
                  ? 'bg-neutral-800 text-white font-semibold border border-neutral-700'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              Div {div.code} ({div.name})
            </button>
          ))}
        </div>
      </div>

      {/* Database Grid */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="sticky top-0 z-20 bg-neutral-900 border-b border-neutral-800 text-neutral-400 font-semibold uppercase tracking-wider text-[11px]">
              <th className="py-2.5 px-3 w-28">Item Code</th>
              <th className="py-2.5 px-3 min-w-72">Description / Specification</th>
              <th className="py-2.5 px-3 w-16 text-center">Unit</th>
              <th className="py-2.5 px-3 w-24 text-right">Labor ($)</th>
              <th className="py-2.5 px-3 w-24 text-right">Daily Output</th>
              <th className="py-2.5 px-3 w-24 text-right">Material ($)</th>
              <th className="py-2.5 px-3 w-24 text-right">Equipment ($)</th>
              <th className="py-2.5 px-3 w-24 text-right">Subcontract ($)</th>
              <th className="py-2.5 px-3 w-28 text-right">Local Unit Rate</th>
              <th className="py-2.5 px-3 w-28 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-900">
            {filtered.map((item) => {
              // Apply regional factor
              const adjustedLabor = item.laborRate * activeRegion.laborFactor;
              const adjustedMaterial = item.materialRate * activeRegion.materialFactor;
              const unitTotal =
                adjustedLabor +
                adjustedMaterial +
                item.equipmentRate +
                item.subcontractorRate;

              return (
                <tr
                  key={item.id}
                  className="hover:bg-neutral-900/50 transition-colors group"
                >
                  <td className="py-2.5 px-3 font-mono-numbers font-medium text-amber-400">
                    {item.itemCode}
                  </td>
                  <td className="py-2.5 px-3 text-neutral-200">
                    <div className="font-medium">{item.description}</div>
                    {item.notes && (
                      <div className="text-[11px] text-neutral-400 mt-0.5">{item.notes}</div>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono-numbers text-neutral-400 font-medium">
                    {item.unit}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-300">
                    {formatCurrencyCents(adjustedLabor)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-400">
                    {formatNumber(item.crewOutputDaily)} {item.unit}/day
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-300">
                    {formatCurrencyCents(adjustedMaterial)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-300">
                    {formatCurrencyCents(item.equipmentRate)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono-numbers text-neutral-300">
                    {item.subcontractorRate > 0 ? formatCurrencyCents(item.subcontractorRate) : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono-numbers font-bold text-neutral-100">
                    {formatCurrencyCents(unitTotal)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => {
                        setPushingItem(item);
                        setPushQuantity(item.unit === 'LS' || item.unit === 'MO' ? 1 : 100);
                      }}
                      className="px-2.5 py-1 bg-neutral-800 hover:bg-amber-600 hover:text-white text-neutral-300 rounded border border-neutral-700 text-xs font-medium transition-colors"
                    >
                      + Add to Bid
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Push to Estimate Quantity Modal */}
      {pushingItem && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-5 max-w-sm w-full shadow-2xl">
            <h3 className="font-bold text-neutral-100 text-sm mb-1">
              Add Item to Master Estimate
            </h3>
            <p className="text-xs text-amber-400 font-semibold mb-3">
              {pushingItem.itemCode} - {pushingItem.description}
            </p>

            <div className="mb-4">
              <label className="text-xs text-neutral-400 block mb-1">
                Enter Project Quantity ({pushingItem.unit}):
              </label>
              <input
                type="number"
                min="0.1"
                step="1"
                autoFocus
                value={pushQuantity}
                onChange={(e) => setPushQuantity(parseFloat(e.target.value) || 0)}
                className="w-full bg-neutral-800 border border-neutral-700 rounded px-3 py-1.5 text-sm font-mono-numbers text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setPushingItem(null)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onPushToEstimate(pushingItem, pushQuantity);
                  setPushingItem(null);
                }}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded transition-colors"
              >
                Insert Line Item
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Custom Item Modal */}
      {isNewItemModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-5 max-w-lg w-full shadow-2xl">
            <h3 className="font-bold text-neutral-100 text-sm mb-3">
              Create Custom Company Unit Cost Item
            </h3>

            <form onSubmit={handleCreateCustomItem} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-400 block mb-1">CSI Division Code</label>
                  <input
                    type="text"
                    required
                    value={newItemForm.divisionCode}
                    onChange={(e) =>
                      setNewItemForm({ ...newItemForm, divisionCode: e.target.value })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Item Code</label>
                  <input
                    type="text"
                    required
                    value={newItemForm.itemCode}
                    onChange={(e) =>
                      setNewItemForm({ ...newItemForm, itemCode: e.target.value })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                  />
                </div>
              </div>

              <div>
                <label className="text-neutral-400 block mb-1">Description & Spec</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 5/8' Type X Drywall with Level 5 Finish"
                  value={newItemForm.description}
                  onChange={(e) =>
                    setNewItemForm({ ...newItemForm, description: e.target.value })
                  }
                  className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-400 block mb-1">Unit of Measure</label>
                  <input
                    type="text"
                    required
                    value={newItemForm.unit}
                    onChange={(e) =>
                      setNewItemForm({ ...newItemForm, unit: e.target.value.toUpperCase() })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Daily Crew Output</label>
                  <input
                    type="number"
                    value={newItemForm.crewOutputDaily}
                    onChange={(e) =>
                      setNewItemForm({
                        ...newItemForm,
                        crewOutputDaily: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="text-neutral-400 block mb-1">Labor ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newItemForm.laborRate}
                    onChange={(e) =>
                      setNewItemForm({ ...newItemForm, laborRate: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1.5 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Material ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newItemForm.materialRate}
                    onChange={(e) =>
                      setNewItemForm({
                        ...newItemForm,
                        materialRate: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1.5 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Equip ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newItemForm.equipmentRate}
                    onChange={(e) =>
                      setNewItemForm({
                        ...newItemForm,
                        equipmentRate: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1.5 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Sub ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newItemForm.subcontractorRate}
                    onChange={(e) =>
                      setNewItemForm({
                        ...newItemForm,
                        subcontractorRate: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1.5 text-neutral-100"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setIsNewItemModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded transition-colors"
                >
                  Save to Database
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
