import React from 'react';
import { Project } from '../types';
import { Sparkles, Layers, Calculator, Database, Users, TrendingUp, FileText } from 'lucide-react';

export type ActiveTab = 'takeoffs' | 'estimate' | 'catalog' | 'subcontractors' | 'analytics' | 'proposal';

interface NavigationProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  projects: Project[];
  activeProject: Project;
  onSelectProject: (projectId: string) => void;
  onOpenAiAssistant: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onTabChange,
  projects,
  activeProject,
  onSelectProject,
  onOpenAiAssistant,
}) => {
  return (
    <header className="h-14 border-b border-neutral-800 bg-neutral-900/95 px-6 flex items-center justify-between gap-4 select-none shrink-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-2">
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            onTabChange('estimate');
          }}
          className="text-lg font-black tracking-tight text-neutral-100 flex items-center gap-2"
        >
          <span className="w-3.5 h-3.5 bg-amber-500 rounded-sm inline-block" />
          <span>Vanguard BidWorks</span>
        </a>
      </div>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-neutral-400">
        <button
          onClick={() => onTabChange('takeoffs')}
          className={`whitespace-nowrap transition-colors flex items-center gap-1.5 py-1 ${
            activeTab === 'takeoffs'
              ? 'text-amber-400 border-b-2 border-amber-400'
              : 'hover:text-neutral-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Plan Takeoffs</span>
        </button>

        <button
          onClick={() => onTabChange('estimate')}
          className={`whitespace-nowrap transition-colors flex items-center gap-1.5 py-1 ${
            activeTab === 'estimate'
              ? 'text-amber-400 border-b-2 border-amber-400'
              : 'hover:text-neutral-200'
          }`}
        >
          <Calculator className="w-3.5 h-3.5" />
          <span>Estimate Spreadsheet</span>
        </button>

        <button
          onClick={() => onTabChange('catalog')}
          className={`whitespace-nowrap transition-colors flex items-center gap-1.5 py-1 ${
            activeTab === 'catalog'
              ? 'text-amber-400 border-b-2 border-amber-400'
              : 'hover:text-neutral-200'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>Cost Database</span>
        </button>

        <button
          onClick={() => onTabChange('subcontractors')}
          className={`whitespace-nowrap transition-colors flex items-center gap-1.5 py-1 ${
            activeTab === 'subcontractors'
              ? 'text-amber-400 border-b-2 border-amber-400'
              : 'hover:text-neutral-200'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Sub Bid Leveling</span>
        </button>

        <button
          onClick={() => onTabChange('analytics')}
          className={`whitespace-nowrap transition-colors flex items-center gap-1.5 py-1 ${
            activeTab === 'analytics'
              ? 'text-amber-400 border-b-2 border-amber-400'
              : 'hover:text-neutral-200'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Win / Loss Analytics</span>
        </button>

        <button
          onClick={() => onTabChange('proposal')}
          className={`whitespace-nowrap transition-colors flex items-center gap-1.5 py-1 ${
            activeTab === 'proposal'
              ? 'text-amber-400 border-b-2 border-amber-400'
              : 'hover:text-neutral-200'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Proposal & Print</span>
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-3">
        {/* Project Selector */}
        <div className="flex items-center gap-1.5">
          <select
            value={activeProject.id}
            onChange={(e) => onSelectProject(e.target.value)}
            className="bg-neutral-800 border border-neutral-700 text-xs font-semibold text-neutral-200 rounded-md px-2.5 py-1.5 focus:outline-none focus:border-amber-500 max-w-48 truncate"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.number} - {p.name}
              </option>
            ))}
          </select>
        </div>

        {/* AI Assistant Button */}
        <button
          onClick={onOpenAiAssistant}
          className="px-3.5 py-1.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-semibold text-xs rounded-md shadow flex items-center gap-1.5 whitespace-nowrap transition-all"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI Estimator</span>
        </button>
      </div>
    </header>
  );
};
