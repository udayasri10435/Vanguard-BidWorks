import React, { useState } from 'react';
import {
  TradePackage,
  SubcontractorBid,
  PlugAdjustment,
  EstimateLineItem,
} from '../../types';
import { formatCurrency, formatPercent } from '../../utils/calculations';
import {
  Users,
  Plus,
  CheckCircle,
  AlertTriangle,
  Award,
  Sparkles,
  FileText,
  DollarSign,
  ShieldCheck,
  Building,
  Info,
} from 'lucide-react';

interface BidLevelingMatrixProps {
  packages: TradePackage[];
  subBids: SubcontractorBid[];
  estimateItems: EstimateLineItem[];
  onAwardSub: (packageId: string, subId: string) => void;
  onUpdateSubBid: (bid: SubcontractorBid) => void;
  onAddSubBid: (bid: SubcontractorBid) => void;
  onAddTradePackage: (pkg: TradePackage) => void;
}

export const BidLevelingMatrix: React.FC<BidLevelingMatrixProps> = ({
  packages,
  subBids,
  estimateItems,
  onAwardSub,
  onUpdateSubBid,
  onAddSubBid,
  onAddTradePackage,
}) => {
  const [activePackageId, setActivePackageId] = useState<string>(
    packages[0]?.id || ''
  );

  // New sub bid modal state
  const [isNewSubModalOpen, setIsNewSubModalOpen] = useState<boolean>(false);
  const [newSubName, setNewSubName] = useState<string>('');
  const [newSubContact, setNewSubContact] = useState<string>('');
  const [newSubPrice, setNewSubPrice] = useState<number>(150000);
  const [newSubNotes, setNewSubNotes] = useState<string>('');

  // AI Leveling Scan Modal
  const [isAiScanModalOpen, setIsAiScanModalOpen] = useState<boolean>(false);
  const [aiRawQuoteText, setAiRawQuoteText] = useState<string>(
    `VoltWorks Electric Quote #VE-992:
Base price: $184,500.
Inclusions: Panels, branch wiring, fixtures, fire alarm.
Exclusions: Mobile crane hoist, temporary power panels, city electrical permit fees, overtime labor.`
  );
  const [isAiScanning, setIsAiScanning] = useState<boolean>(false);
  const [aiScanResult, setAiScanResult] = useState<any>(null);

  const activePackage = packages.find((p) => p.id === activePackageId) || packages[0];
  const packageBids = activePackage
    ? subBids.filter((b) => b.tradePackageId === activePackage.id)
    : [];

  // Toggle scope inclusion
  const handleToggleScope = (bid: SubcontractorBid, scopeId: string) => {
    const isCurrentlyIncluded = !!bid.scopeInclusions[scopeId];
    const newInclusions = {
      ...bid.scopeInclusions,
      [scopeId]: !isCurrentlyIncluded,
    };

    // If was included and now excluded, add plug adjustment if none exists
    let newPlugs = [...bid.plugAdjustments];
    const scopeDef = activePackage?.requiredScopes.find((s) => s.id === scopeId);

    if (isCurrentlyIncluded) {
      // Just excluded -> add plug
      if (!newPlugs.some((p) => p.scopeItem === scopeDef?.label)) {
        newPlugs.push({
          id: 'pa-' + Date.now(),
          scopeItem: scopeDef?.label || 'Omitted Scope Item',
          amount: scopeDef?.defaultPlugEstimate || 3000,
          reason: 'Excluded by subcontractor in bid proposal',
        });
      }
    } else {
      // Now included -> remove plug
      newPlugs = newPlugs.filter((p) => p.scopeItem !== scopeDef?.label);
    }

    const plugTotal = newPlugs.reduce((acc, p) => acc + p.amount, 0);
    const normalizedTotal = bid.basePrice + plugTotal;

    onUpdateSubBid({
      ...bid,
      scopeInclusions: newInclusions,
      plugAdjustments: newPlugs,
      normalizedTotal,
    });
  };

  // Update plug dollar amount
  const handleUpdatePlugAmount = (
    bid: SubcontractorBid,
    plugId: string,
    amount: number
  ) => {
    const updatedPlugs = bid.plugAdjustments.map((p) =>
      p.id === plugId ? { ...p, amount } : p
    );
    const plugTotal = updatedPlugs.reduce((acc, p) => acc + p.amount, 0);
    const normalizedTotal = bid.basePrice + plugTotal;

    onUpdateSubBid({
      ...bid,
      plugAdjustments: updatedPlugs,
      normalizedTotal,
    });
  };

  // Create new manual sub bid
  const handleCreateSubBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubName || !activePackage) return;

    const inclusions: { [k: string]: boolean } = {};
    activePackage.requiredScopes.forEach((s) => {
      inclusions[s.id] = true;
    });

    const newBid: SubcontractorBid = {
      id: 'sub-' + Date.now(),
      tradePackageId: activePackage.id,
      subName: newSubName,
      contactPerson: newSubContact || 'Lead Estimator',
      phone: '(512) 555-0100',
      email: 'bids@company.com',
      quoteDate: new Date().toISOString().split('T')[0],
      basePrice: newSubPrice,
      scopeInclusions: inclusions,
      plugAdjustments: [],
      normalizedTotal: newSubPrice,
      isAwarded: false,
      licenseVerified: true,
      insuranceOnFile: true,
      notes: newSubNotes,
    };

    onAddSubBid(newBid);
    setIsNewSubModalOpen(false);
    setNewSubName('');
  };

  // Run AI Scope Leveling
  const handleRunAiLeveling = async () => {
    setIsAiScanning(true);
    setAiScanResult(null);
    try {
      const res = await fetch('/api/ai/level-sub-bids', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tradePackage: activePackage?.name,
          quotesText: aiRawQuoteText,
          requiredScopes: activePackage?.requiredScopes.map((s) => s.label),
        }),
      });
      const data = await res.json();
      setAiScanResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAiScanning(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-950 overflow-hidden">
      {/* Top Banner */}
      <div className="p-3.5 bg-neutral-900 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Users className="w-5 h-5 text-amber-500" />
          <div>
            <h2 className="text-sm font-bold text-neutral-100">
              Subcontractor Bid Leveling Matrix & RFP Comparison
            </h2>
            <p className="text-xs text-neutral-400">
              Normalize quotes side-by-side with scope checklists and plug adjustments
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAiScanModalOpen(true)}
            className="px-3 py-1.5 bg-sky-950/80 hover:bg-sky-900 text-sky-300 font-medium text-xs rounded border border-sky-700/80 flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>AI Scope Gap Scanner</span>
          </button>

          <button
            onClick={() => setIsNewSubModalOpen(true)}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Sub Bid</span>
          </button>
        </div>
      </div>

      {/* Package Tabs */}
      <div className="px-3 pt-2 bg-neutral-900/60 border-b border-neutral-800 flex items-center gap-1 overflow-x-auto">
        {packages.map((pkg) => {
          const isSelected = pkg.id === activePackageId;
          const count = subBids.filter((b) => b.tradePackageId === pkg.id).length;
          return (
            <button
              key={pkg.id}
              onClick={() => setActivePackageId(pkg.id)}
              className={`px-3 py-2 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
                isSelected
                  ? 'bg-neutral-950 border-neutral-700 text-amber-400'
                  : 'bg-neutral-900/40 border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {pkg.name} ({count} bids)
            </button>
          );
        })}
      </div>

      {/* Main Comparison Matrix */}
      <div className="flex-1 overflow-auto p-4">
        {packageBids.length === 0 ? (
          <div className="py-20 text-center text-xs text-neutral-500">
            <Building className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
            <p className="text-sm font-semibold text-neutral-300">
              No subcontractor bids logged for {activePackage?.name}.
            </p>
            <p className="mt-1 text-neutral-500">
              Click &quot;Log Sub Bid&quot; or use the AI Scope Gap Scanner to parse incoming quote emails.
            </p>
          </div>
        ) : (
          <div className="border border-neutral-800 rounded-xl overflow-hidden bg-neutral-900/60 shadow-xl">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-neutral-900 border-b border-neutral-800">
                  <th className="py-3 px-4 text-left w-72 text-neutral-400 font-semibold uppercase tracking-wider text-[11px]">
                    Trade Scope Checklist
                  </th>
                  {packageBids.map((bid) => {
                    const isAwarded = bid.isAwarded;
                    return (
                      <th
                        key={bid.id}
                        className={`py-3 px-4 text-center min-w-56 border-l border-neutral-800 ${
                          isAwarded ? 'bg-amber-500/10' : ''
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-bold text-neutral-100 text-sm truncate">
                            {bid.subName}
                          </span>
                          {isAwarded && (
                            <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-1.5 py-0.5 rounded border border-amber-500/30 flex items-center gap-1">
                              <Award className="w-3 h-3" />
                              AWARDED
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-400 text-left mt-0.5">
                          {bid.contactPerson} · {bid.quoteDate}
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>

              <tbody className="divide-y divide-neutral-800">
                {/* 1. Base Quoted Price */}
                <tr className="bg-neutral-950/70 font-semibold">
                  <td className="py-2.5 px-4 text-neutral-300">1. Base Proposal Price</td>
                  {packageBids.map((bid) => (
                    <td
                      key={bid.id}
                      className="py-2.5 px-4 text-center font-mono-numbers font-bold text-neutral-100 border-l border-neutral-800"
                    >
                      {formatCurrency(bid.basePrice)}
                    </td>
                  ))}
                </tr>

                {/* 2. Scope Items Rows */}
                {activePackage?.requiredScopes.map((scope) => (
                  <tr key={scope.id} className="hover:bg-neutral-850 transition-colors">
                    <td className="py-2 px-4 text-neutral-300">
                      <div className="font-medium">{scope.label}</div>
                      <div className="text-[10px] text-neutral-500 font-mono-numbers">
                        Default plug allowance: {formatCurrency(scope.defaultPlugEstimate)}
                      </div>
                    </td>

                    {packageBids.map((bid) => {
                      const isIncluded = !!bid.scopeInclusions[scope.id];

                      return (
                        <td
                          key={bid.id}
                          className="py-2 px-4 text-center border-l border-neutral-800 cursor-pointer"
                          onClick={() => handleToggleScope(bid, scope.id)}
                        >
                          <div className="inline-flex items-center gap-1.5">
                            {isIncluded ? (
                              <span className="flex items-center gap-1 text-emerald-400 font-semibold text-xs">
                                <CheckCircle className="w-3.5 h-3.5" />
                                <span>Included</span>
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 text-rose-400 font-semibold text-xs bg-rose-950/40 px-2 py-0.5 rounded border border-rose-900/60">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                <span>EXCLUDED</span>
                              </span>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}

                {/* 3. Plug Adjustments Header */}
                <tr className="bg-neutral-950/80 font-bold text-neutral-300">
                  <td className="py-2 px-4">
                    2. Normalization Plugs (Missed Scope Additions)
                  </td>
                  {packageBids.map((bid) => {
                    const totalPlugs = bid.plugAdjustments.reduce(
                      (acc, p) => acc + p.amount,
                      0
                    );
                    return (
                      <td
                        key={bid.id}
                        className="py-2 px-4 text-center font-mono-numbers text-rose-400 border-l border-neutral-800 font-bold"
                      >
                        +{formatCurrency(totalPlugs)}
                      </td>
                    );
                  })}
                </tr>

                {/* Plug Details Row */}
                <tr>
                  <td className="py-2 px-4 text-neutral-400 text-[11px] align-top">
                    Itemized plug values added to normalize exclusions
                  </td>
                  {packageBids.map((bid) => (
                    <td
                      key={bid.id}
                      className="py-2 px-3 text-left border-l border-neutral-800 align-top"
                    >
                      {bid.plugAdjustments.length === 0 ? (
                        <span className="text-neutral-500 italic text-[11px]">
                          No scope plugs required
                        </span>
                      ) : (
                        <div className="space-y-1.5">
                          {bid.plugAdjustments.map((plug) => (
                            <div
                              key={plug.id}
                              className="p-1.5 rounded bg-neutral-950 border border-neutral-800 text-[11px]"
                            >
                              <div className="flex justify-between font-medium text-neutral-300">
                                <span className="truncate max-w-32">{plug.scopeItem}</span>
                                <input
                                  type="number"
                                  value={plug.amount}
                                  onChange={(e) =>
                                    handleUpdatePlugAmount(
                                      bid,
                                      plug.id,
                                      parseFloat(e.target.value) || 0
                                    )
                                  }
                                  className="w-16 text-right font-mono-numbers text-rose-400 bg-neutral-900 border border-neutral-700 rounded px-1"
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </td>
                  ))}
                </tr>

                {/* 4. TRUE NORMALIZED LEVELIZED TOTAL */}
                <tr className="bg-neutral-900 font-bold text-sm border-t-2 border-amber-500/40">
                  <td className="py-3 px-4 text-neutral-100">
                    <div>3. Total Levelized Bid (Normalized)</div>
                    <div className="text-[10px] text-neutral-400 font-normal">
                      Base price + all plugged omissions
                    </div>
                  </td>
                  {packageBids.map((bid) => {
                    const isLowest = Math.min(...packageBids.map((b) => b.normalizedTotal)) === bid.normalizedTotal;

                    return (
                      <td
                        key={bid.id}
                        className={`py-3 px-4 text-center font-mono-numbers text-base border-l border-neutral-800 font-extrabold ${
                          isLowest ? 'text-emerald-400 bg-emerald-950/20' : 'text-neutral-200'
                        }`}
                      >
                        <div>{formatCurrency(bid.normalizedTotal)}</div>
                        {isLowest && (
                          <div className="text-[10px] text-emerald-400 uppercase tracking-wider font-bold">
                            Lowest Levelized Cost
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>

                {/* Sub Compliance & Actions */}
                <tr className="bg-neutral-950">
                  <td className="py-3 px-4 text-neutral-400">
                    Vendor Compliance & Award Decision
                  </td>
                  {packageBids.map((bid) => (
                    <td
                      key={bid.id}
                      className="py-3 px-4 text-center border-l border-neutral-800"
                    >
                      <div className="flex items-center justify-center gap-2 mb-2 text-xs text-neutral-400">
                        <span className="flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Insurance OK</span>
                        </span>
                      </div>

                      {bid.isAwarded ? (
                        <div className="py-1 px-3 bg-amber-500/20 text-amber-300 font-semibold rounded text-xs border border-amber-500/40">
                          Awarded to Master Estimate
                        </div>
                      ) : (
                        <button
                          onClick={() => onAwardSub(activePackage.id, bid.id)}
                          className="w-full py-1.5 px-3 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded text-xs transition-colors flex items-center justify-center gap-1.5 shadow"
                        >
                          <Award className="w-3.5 h-3.5" />
                          <span>Award & Plug to Estimate</span>
                        </button>
                      )}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manual Add Sub Bid Modal */}
      {isNewSubModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-5 max-w-md w-full shadow-2xl">
            <h3 className="font-bold text-neutral-100 text-sm mb-3">
              Log Subcontractor Proposal for {activePackage?.name}
            </h3>

            <form onSubmit={handleCreateSubBid} className="space-y-3 text-xs">
              <div>
                <label className="text-neutral-400 block mb-1">Subcontractor Company</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apex Current Contractors"
                  value={newSubName}
                  onChange={(e) => setNewSubName(e.target.value)}
                  className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-400 block mb-1">Estimator Contact</label>
                  <input
                    type="text"
                    value={newSubContact}
                    onChange={(e) => setNewSubContact(e.target.value)}
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">Base Price ($)</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={newSubPrice}
                    onChange={(e) => setNewSubPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 font-mono-numbers text-neutral-100"
                  />
                </div>
              </div>

              <div>
                <label className="text-neutral-400 block mb-1">Proposal Notes & Exclusions</label>
                <textarea
                  rows={3}
                  value={newSubNotes}
                  onChange={(e) => setNewSubNotes(e.target.value)}
                  placeholder="Note any exclusions, lead times, or special terms..."
                  className="w-full bg-neutral-800 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setIsNewSubModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded transition-colors"
                >
                  Save Proposal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AI Scope Gap Scanner Modal */}
      {isAiScanModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-5 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-sky-400" />
              <h3 className="font-bold text-neutral-100 text-sm">
                AI Subcontractor Scope Gap & Leveling Scanner
              </h3>
            </div>
            <p className="text-xs text-neutral-400 mb-3">
              Paste raw sub quote emails or proposal text. Gemini detects hidden caveats, missing
              permits, and calculates normalized dollar plug values.
            </p>

            <textarea
              rows={5}
              value={aiRawQuoteText}
              onChange={(e) => setAiRawQuoteText(e.target.value)}
              placeholder="Paste email text or proposal notes..."
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-3 text-xs font-mono text-neutral-200 focus:outline-none focus:border-sky-500 mb-3"
            />

            <div className="flex justify-end mb-4">
              <button
                disabled={isAiScanning}
                onClick={handleRunAiLeveling}
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-semibold text-xs rounded flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isAiScanning ? 'Analyzing Quotes...' : 'Analyze & Level Quotes'}</span>
              </button>
            </div>

            {aiScanResult && (
              <div className="p-3.5 bg-neutral-950 rounded-lg border border-neutral-800 text-xs space-y-3">
                <div className="p-2.5 bg-neutral-900 rounded border border-neutral-800">
                  <span className="font-bold text-amber-400 block mb-1">Chief Estimator Verdict:</span>
                  <p className="text-neutral-300 leading-relaxed">{aiScanResult.levelingVerdict}</p>
                </div>

                <div className="space-y-2">
                  <span className="font-bold text-neutral-200 block">Identified Sub Proposals:</span>
                  {aiScanResult.subcontractorAnalyses?.map((sub: any, i: number) => (
                    <div
                      key={i}
                      className="p-2.5 bg-neutral-900 rounded border border-neutral-800 space-y-1.5"
                    >
                      <div className="flex justify-between font-bold">
                        <span className="text-neutral-100">{sub.subName}</span>
                        <span className="text-amber-400 font-mono-numbers">
                          Normalized: {formatCurrency(sub.normalizedPrice)} (Base: {formatCurrency(sub.basePrice)})
                        </span>
                      </div>
                      <div className="text-neutral-400">
                        <strong>Exclusions Found:</strong> {sub.exclusionsFound?.join(', ')}
                      </div>
                      <div className="space-y-1">
                        {sub.recommendedPlugs?.map((p: any, idx: number) => (
                          <div key={idx} className="flex justify-between text-neutral-400">
                            <span>• {p.scopeItem}</span>
                            <span className="font-mono-numbers text-rose-400">+{formatCurrency(p.plugValue)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end mt-4 pt-3 border-t border-neutral-800">
              <button
                onClick={() => setIsAiScanModalOpen(false)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
