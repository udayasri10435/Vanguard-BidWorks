export type SectorType =
  | 'Commercial Office'
  | 'Healthcare & Medical'
  | 'Retail & Restaurant'
  | 'Industrial & Warehouse'
  | 'Multi-Family Residential'
  | 'Educational / Institutional'
  | 'Tenant Improvement';

export type BidStatus = 'drafting' | 'review' | 'submitted' | 'won' | 'lost';

export interface Project {
  id: string;
  name: string;
  number: string;
  client: string;
  architect: string;
  location: string;
  regionFactorKey: string;
  sector: SectorType;
  squareFootage: number;
  bidDueDate: string;
  status: BidStatus;
  notes: string;
  createdDate: string;
}

export type TakeoffToolType = 'area' | 'linear' | 'count';

export interface Point {
  x: number;
  y: number;
}

export interface TakeoffItem {
  id: string;
  projectId: string;
  sheetId: string;
  name: string;
  divisionCode: string;
  toolType: TakeoffToolType;
  points: Point[];
  measurementValue: number; // SF, LF, or Count
  unit: 'SF' | 'LF' | 'EA' | 'CY';
  depthInches?: number; // for volume (CY) calculation from area
  heightFeet?: number; // for wall area (SF) from linear length
  color: string;
  linkedEstimateItemId?: string;
}

export interface PlanSheet {
  id: string;
  projectId: string;
  sheetNumber: string;
  name: string;
  category: 'Architectural' | 'Structural' | 'MEP Electrical' | 'Custom';
  scaleRatio: number; // pixels per foot
  scaleLabel: string;
  dimensions: { width: number; height: number };
  svgTemplate: 'commercial_floorplan' | 'foundation_plan' | 'mep_plan' | 'custom';
  customImageUrl?: string;
}

export interface CostDatabaseItem {
  id: string;
  divisionCode: string;
  divisionName: string;
  itemCode: string;
  description: string;
  unit: string;
  laborRate: number; // $ per unit
  crewOutputDaily: number; // units per day
  materialRate: number; // $ per unit
  equipmentRate: number; // $ per unit
  subcontractorRate: number; // $ per unit
  notes?: string;
  isCustom?: boolean;
}

export interface EstimateLineItem {
  id: string;
  projectId: string;
  divisionCode: string;
  divisionName: string;
  itemCode: string;
  description: string;
  takeoffId?: string;
  takeoffLabel?: string;
  quantity: number;
  unit: string;
  laborRate: number;
  materialRate: number;
  equipmentRate: number;
  subcontractorRate: number;
  notes?: string;
}

export interface EstimateFinancials {
  directLaborTotal: number;
  directMaterialTotal: number;
  directEquipmentTotal: number;
  directSubcontractTotal: number;
  directCostTotal: number;

  generalConditionsPercent: number; // % of direct costs
  generalConditionsAmount: number;
  contingencyPercent: number; // % of (direct + GC)
  contingencyAmount: number;
  overheadPercent: number; // %
  overheadAmount: number;

  netCostTotal: number;

  targetProfitMarginPercent: number; // % markup
  targetProfitMarginAmount: number;

  bondRatePercent: number;
  bondAmount: number;
  insuranceRatePercent: number;
  insuranceAmount: number;

  grossBidTotal: number;
  grossProfitTotal: number;
  grossMarginPercent: number;
  costPerSF: number;
}

export interface PlugAdjustment {
  id: string;
  scopeItem: string;
  amount: number;
  reason: string;
}

export interface SubcontractorBid {
  id: string;
  tradePackageId: string;
  subName: string;
  contactPerson: string;
  phone: string;
  email: string;
  quoteDate: string;
  basePrice: number;
  scopeInclusions: { [scopeKey: string]: boolean };
  plugAdjustments: PlugAdjustment[];
  normalizedTotal: number;
  isAwarded: boolean;
  licenseVerified: boolean;
  insuranceOnFile: boolean;
  notes: string;
}

export interface TradePackage {
  id: string;
  projectId: string;
  name: string;
  divisionCode: string;
  budgetEstimate: number;
  requiredScopes: Array<{ id: string; label: string; defaultPlugEstimate: number }>;
  awardedSubId?: string;
  linkedEstimateItemId?: string;
}

export interface HistoricalBid {
  id: string;
  projectName: string;
  sector: SectorType;
  squareFootage: number;
  ownerClient: string;
  architect: string;
  bidDate: string;
  ourBidAmount: number;
  winningBidAmount: number;
  spreadPercent: number; // difference: ((ourBid - winBid) / winBid) * 100
  plannedMarginPercent: number;
  status: 'won' | 'lost' | 'pending';
  lossReason?: string;
  competitorWinner?: string;
}

export interface RegionalModifier {
  key: string;
  name: string;
  state: string;
  laborFactor: number;
  materialFactor: number;
}
